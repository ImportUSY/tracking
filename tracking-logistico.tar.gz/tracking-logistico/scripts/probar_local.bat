@echo off
setlocal
title Tracking Logistico - en tu PC
cd /d "%~dp0.."

rem --- 1. Python ---------------------------------------------------------
set "HAYPY="
py -3 --version >nul 2>&1 && set "HAYPY=1"
if not defined HAYPY python --version >nul 2>&1 && set "HAYPY=1"
if not defined HAYPY (
  echo.
  echo  Falta Python 3.10 o superior.
  echo  Instalelo con este comando en PowerShell:   winget install Python.Python.3.12
  echo  o desde https://www.python.org/downloads/   ^(marque "Add python.exe to PATH"^)
  echo  Luego vuelva a abrir este archivo.
  echo.
  pause
  exit /b 1
)

rem --- 2. Instalacion (solo la primera vez) ------------------------------
if not exist ".venv\Scripts\tracking.exe" (
  echo.
  echo  == Primera vez: instalando el programa. Tarda de 1 a 3 minutos ==
  powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\setup.ps1"
  if errorlevel 1 goto fallo
)

rem --- 3. Usuario supervisor (solo la primera vez) ------------------------
if not exist "data\supervisor.ok" (
  echo.
  echo  == Cree la clave del usuario "supervisor" ==
  echo     Minimo 6 caracteres. Al escribirla no se ve nada: es normal.
  ".venv\Scripts\tracking.exe" crear-supervisor
  if errorlevel 1 goto fallo
  if not exist data mkdir data
  echo ok> "data\supervisor.ok"
)

rem --- 4. Arrancar ----------------------------------------------------------
echo.
echo  ============================================================
echo   PROGRAMA EN MARCHA. Deje esta ventana abierta mientras lo usa.
echo.
echo   Panel (Transporte, Cobranzas):  http://localhost:8000
echo   App del conductor:              http://localhost:8000/conductor
echo   Consulta de vendedores:         http://localhost:8000/tracking
echo.
echo   Usuario: supervisor    Clave: la que creo la primera vez
echo   Para detenerlo: cierre esta ventana.
echo  ============================================================
echo.
start "" /min cmd /c "timeout /t 6 /nobreak >nul && start http://localhost:8000"
".venv\Scripts\tracking.exe" serve --host 0.0.0.0 --port 8000
goto :eof

:fallo
echo.
echo  Ocurrio un error. Revise los mensajes de arriba o consulte "EMPIEZA AQUI.html".
pause
exit /b 1
