"use strict";
(() => {
  const { $, api, setSession, user, token } = TL;
  TL.registerSW();

  function destino(u) { return u.rol === "conductor" ? "/conductor" : "/panel"; }

  // Sesión vigente: ir directo
  const u0 = user();
  if (token() && u0 && !u0.debe_cambiar_clave) {
    location.replace(destino(u0));
    return;
  }

  let claveActual = "";

  $("#login").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const err = $("#err");
    err.classList.add("hidden");
    $("#btn").disabled = true;
    try {
      const username = $("#u").value.trim();
      claveActual = $("#p").value;
      const r = await api("/api/auth/login", { method: "POST", body: { username, password: claveActual }, onUnauthorized: false });
      setSession(r.access_token, r.usuario);
      if (r.usuario.debe_cambiar_clave) {
        $("#login").classList.add("hidden");
        $("#cambio").classList.remove("hidden");
        $("#n1").focus();
      } else {
        location.replace(destino(r.usuario));
      }
    } catch (e) {
      err.textContent = navigator.onLine ? e.message : "Sin conexión. Necesita señal para iniciar sesión la primera vez.";
      err.classList.remove("hidden");
    } finally {
      $("#btn").disabled = false;
    }
  });

  $("#cambio").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const err = $("#err2");
    err.classList.add("hidden");
    const n1 = $("#n1").value, n2 = $("#n2").value;
    if (n1 !== n2) { err.textContent = "Las claves no coinciden"; err.classList.remove("hidden"); return; }
    try {
      const r = await api("/api/me/clave", { method: "POST", body: { clave_actual: claveActual, clave_nueva: n1 } });
      setSession(r.access_token, r.usuario);
      location.replace(destino(r.usuario));
    } catch (e) {
      err.textContent = e.message; err.classList.remove("hidden");
    }
  });
})();
