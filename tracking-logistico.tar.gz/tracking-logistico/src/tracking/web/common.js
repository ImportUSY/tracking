/* Utilidades compartidas: sesión, llamadas a la API, formato y UI básica. */
"use strict";

const TL = (() => {
  const TOKEN_KEY = "tl_token";
  const USER_KEY = "tl_user";

  const ESTATUS = {
    recibida: "Recibida",
    cargado: "Cargado",
    en_transito: "En Tránsito",
    entregada: "Entregada",
    devolucion: "Devolución",
  };
  const ORDEN = { recibida: 0, cargado: 1, en_transito: 2, entregada: 3, devolucion: 3 };

  function store(key, value) {
    try {
      if (value === null) localStorage.removeItem(key);
      else localStorage.setItem(key, value);
    } catch (_) { /* almacenamiento bloqueado: la sesión dura lo que la pestaña */ }
  }
  function read(key) {
    try { return localStorage.getItem(key); } catch (_) { return null; }
  }

  let memToken = read(TOKEN_KEY);
  let memUser = (() => { try { return JSON.parse(read(USER_KEY) || "null"); } catch (_) { return null; } })();

  function setSession(token, user) {
    memToken = token; memUser = user;
    store(TOKEN_KEY, token); store(USER_KEY, user ? JSON.stringify(user) : null);
  }
  function clearSession() { setSession(null, null); }
  function token() { return memToken; }
  function user() { return memUser; }

  class ApiError extends Error {
    constructor(status, message, body) { super(message); this.status = status; this.body = body; }
  }

  async function api(path, opts = {}) {
    const headers = Object.assign({}, opts.headers || {});
    if (memToken) headers["Authorization"] = "Bearer " + memToken;
    let body = opts.body;
    if (body instanceof Blob) {
      headers["Content-Type"] = body.type || "application/octet-stream";
    } else if (body && !(body instanceof FormData) && typeof body !== "string") {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(body);
    }
    const res = await fetch(path, { method: opts.method || "GET", headers, body, cache: "no-store" });
    if (opts.raw) {
      if (!res.ok) throw new ApiError(res.status, await errorText(res));
      return res;
    }
    let data = null;
    const ct = res.headers.get("content-type") || "";
    if (ct.includes("application/json")) data = await res.json();
    if (!res.ok) {
      if (res.status === 401 && opts.onUnauthorized !== false) onUnauthorized();
      throw new ApiError(res.status, detail(data) || ("Error " + res.status), data);
    }
    return data;
  }

  async function errorText(res) {
    try { return detail(await res.json()) || ("Error " + res.status); } catch (_) { return "Error " + res.status; }
  }
  function detail(data) {
    if (!data) return "";
    if (typeof data.detail === "string") return data.detail;
    if (Array.isArray(data.detail)) return data.detail.map((d) => d.msg).join("; ");
    return "";
  }

  let unauthorizedHandler = () => { clearSession(); location.href = "/"; };
  function onUnauthorized() { unauthorizedHandler(); }
  function setUnauthorizedHandler(fn) { unauthorizedHandler = fn; }

  function esc(v) {
    return String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  function fmtFechaHora(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    return d.toLocaleString("es-VE", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
  }
  function fmtFecha(iso) {
    if (!iso) return "";
    const [y, m, d] = String(iso).slice(0, 10).split("-");
    return `${d}/${m}/${y}`;
  }
  function fmtMonto(v) {
    if (v === null || v === undefined || v === "") return "";
    return Number(v).toLocaleString("es-VE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function badge(estatus) {
    return `<span class="badge s-${esc(estatus)}">${esc(ESTATUS[estatus] || estatus)}</span>`;
  }

  let toastTimer = null;
  function toast(msg, ms = 3500) {
    let el = document.getElementById("tl-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "tl-toast"; el.className = "toast"; el.setAttribute("role", "status");
      document.body.appendChild(el);
    }
    el.textContent = msg; el.classList.remove("hidden");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.add("hidden"), ms);
  }

  function uuid() {
    if (crypto.randomUUID) return crypto.randomUUID();
    const b = crypto.getRandomValues(new Uint8Array(16));
    b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80;
    const h = [...b].map((x) => x.toString(16).padStart(2, "0")).join("");
    return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
  }

  function $(sel, root = document) { return root.querySelector(sel); }
  function $$(sel, root = document) { return [...root.querySelectorAll(sel)]; }

  function registerSW() {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(() => {});
    }
  }

  async function download(path, fallbackName) {
    const res = await api(path, { raw: true });
    const blob = await res.blob();
    const cd = res.headers.get("content-disposition") || "";
    const m = cd.match(/filename="?([^"]+)"?/);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = m ? m[1] : fallbackName;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }

  return {
    ESTATUS, ORDEN, api, ApiError, setSession, clearSession, token, user, setUnauthorizedHandler,
    esc, fmtFechaHora, fmtFecha, fmtMonto, badge, toast, uuid, $, $$, registerSW, download,
  };
})();
