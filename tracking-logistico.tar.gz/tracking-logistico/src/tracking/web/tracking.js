"use strict";
(() => {
  const { $, esc, fmtFechaHora } = TL;
  const COLORES = { "Recibida": "recibida", "Cargado": "cargado", "En Tránsito": "en_transito", "Entregada": "entregada", "Devolución": "devolucion" };

  async function consultar(q) {
    const out = $("#out");
    out.innerHTML = '<div class="card muted">Buscando…</div>';
    try {
      const res = await fetch("/api/publico/tracking?q=" + encodeURIComponent(q), { cache: "no-store" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === "string" ? data.detail : "No se pudo consultar. Intente de nuevo.");
      if (!data.encontrado) { out.innerHTML = `<div class="card">${esc(data.mensaje)}</div>`; return; }
      out.innerHTML = data.resultados.map((r) => `
        <article class="card stack">
          <div class="row between">
            <div><strong class="mono">${esc(r.numero)}</strong><br><small>${esc(r.empresa || "")}</small></div>
            <span class="badge s-${COLORES[r.estatus] || "recibida"}" style="font-size:.95rem">${esc(r.estatus)}</span>
          </div>
          <div class="grid">
            <div><small>Cliente</small><div>${esc(r.cliente || "-")}</div></div>
            <div><small>Pedido</small><div class="mono">${esc(r.pedido || "-")}</div></div>
            <div><small>Tracking</small><div class="mono">${esc(r.tracking || "Aún no asignado")}</div></div>
            <div><small>Destino</small><div>${esc(r.destino || "-")}</div></div>
          </div>
          <div>
            <small>Historial</small>
            <ul class="timeline">${r.historial.map((h) => `<li><strong>${esc(h.estatus)}</strong> · ${esc(fmtFechaHora(h.fecha))}</li>`).join("")}</ul>
          </div>
        </article>`).join("");
    } catch (e) {
      out.innerHTML = `<div class="alert err">${esc(e.message)}</div>`;
    }
  }

  $("#f").addEventListener("submit", (e) => {
    e.preventDefault();
    const q = $("#q").value.trim();
    history.replaceState(null, "", "?q=" + encodeURIComponent(q));
    consultar(q);
  });
  const inicial = new URLSearchParams(location.search).get("q");
  if (inicial) { $("#q").value = inicial; consultar(inicial); }
})();
