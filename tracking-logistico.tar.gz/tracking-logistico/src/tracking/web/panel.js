"use strict";
(async () => {
  const { $, $$, api, esc, badge, fmtFechaHora, fmtFecha, fmtMonto, toast, ESTATUS } = TL;

  const me = TL.user();
  if (!TL.token() || !me || me.rol === "conductor") { location.replace("/"); return; }
  // Permisos efectivos (RBAC) calculados por el servidor: la interfaz solo muestra lo permitido.
  // El servidor vuelve a validar cada acción; ocultar un botón no es la medida de seguridad.
  const PERM = new Set((await api("/api/me/permisos")).permisos);
  const puede = (p) => PERM.has(p);
  const PUEDE_EDITAR = puede("catalogos.gestionar");
  const ROLES = { supervisor: "Supervisor", transportista: "Transportista", cobranzas: "Cobranzas", conductor: "Conductor" };
  $("#quien").textContent = `${me.nombre} · ${ROLES[me.rol] || me.rol}`;

  // ------------------------------------------------------------------ diálogo genérico
  const dlg = $("#dlg");
  let dlgSubmit = null;
  function abrirDialogo(html, botones, onSubmit) {
    $("#dlgBody").innerHTML = html;
    $("#dlgFoot").innerHTML = botones;
    dlgSubmit = onSubmit;
    dlg.showModal();
    const first = $("#dlgBody input, #dlgBody select, #dlgBody textarea");
    if (first) first.focus();
  }
  $("#dlgForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!dlgSubmit) { dlg.close(); return; }
    const err = $("#dlgErr");
    try {
      const cerrar = await dlgSubmit(new FormData($("#dlgForm")), e.submitter);
      if (cerrar !== false) dlg.close();
    } catch (ex) {
      if (err) { err.textContent = ex.message; err.classList.remove("hidden"); } else toast(ex.message);
    }
  });
  $("#dlgFoot").addEventListener("click", (e) => { if (e.target.dataset.cerrar !== undefined) dlg.close(); });

  function campo(f) {
    const v = f.value ?? "";
    if (f.type === "select") {
      return `<div><label for="f_${f.name}">${esc(f.label)}</label><select id="f_${f.name}" name="${f.name}">
        ${f.options.map(([k, t]) => `<option value="${esc(k)}" ${String(k) === String(v) ? "selected" : ""}>${esc(t)}</option>`).join("")}</select></div>`;
    }
    if (f.type === "checkbox") {
      return `<div class="row"><input type="checkbox" id="f_${f.name}" name="${f.name}" ${v ? "checked" : ""}><label for="f_${f.name}" style="margin:0">${esc(f.label)}</label></div>`;
    }
    if (f.type === "textarea") {
      return `<div><label for="f_${f.name}">${esc(f.label)}</label><textarea id="f_${f.name}" name="${f.name}" ${f.required ? "required" : ""}>${esc(v)}</textarea></div>`;
    }
    return `<div><label for="f_${f.name}">${esc(f.label)}</label><input id="f_${f.name}" name="${f.name}" type="${f.type || "text"}"
      value="${esc(v)}" ${f.required ? "required" : ""} ${f.readonly ? "readonly" : ""} ${f.min ? `minlength="${f.min}"` : ""}></div>`;
  }
  function formulario(titulo, campos, onSubmit, okTxt = "Guardar") {
    abrirDialogo(`<h2 style="margin-top:0">${esc(titulo)}</h2>${campos.map(campo).join("")}<div id="dlgErr" class="alert err hidden"></div>`,
      `<button type="button" data-cerrar>Cancelar</button><button type="submit" class="primary">${esc(okTxt)}</button>`, onSubmit);
  }
  function datos(fd, campos) {
    const o = {};
    for (const c of campos) {
      if (c.type === "checkbox") o[c.name] = fd.get(c.name) === "on";
      else { const v = (fd.get(c.name) || "").toString().trim(); o[c.name] = v === "" ? null : v; }
    }
    return o;
  }
  function mostrarCredenciales(creds, titulo = "Claves temporales") {
    if (!creds || !creds.length) return;
    abrirDialogo(`<h2 style="margin-top:0">${esc(titulo)}</h2>
      <p class="muted">Entregue cada clave a su dueño. Se mostrará <strong>solo esta vez</strong>; al entrar se le pedirá cambiarla.</p>
      <div class="table-wrap"><table><tr><th>Usuario</th><th>Nombre</th><th>Clave temporal</th></tr>
      ${creds.map((c) => `<tr><td class="mono">${esc(c.usuario)}</td><td>${esc(c.nombre)}</td><td class="mono"><strong>${esc(c.clave_temporal)}</strong></td></tr>`).join("")}
      </table></div>`, `<button type="button" id="btnPrint">Imprimir</button><button type="submit" class="primary">Listo</button>`, null);
    $("#btnPrint").onclick = () => window.print();
  }

  // ------------------------------------------------------------------ navegación
  const TABS = [
    { id: "inicio", t: "Inicio", fn: vistaInicio },
    { id: "cargar", t: "Cargar REMESA", fn: vistaCargar, perm: "remesas.importar" },
    { id: "remesas", t: "Remesas", fn: vistaRemesas },
    { id: "facturas", t: "Facturas", fn: vistaFacturas },
    { id: "conductores", t: "Conductores", fn: vistaConductores },
    { id: "camiones", t: "Camiones", fn: vistaCamiones },
    { id: "vendedores", t: "Vendedores", fn: vistaVendedores },
    { id: "usuarios", t: "Usuarios", fn: vistaUsuarios, perm: "usuarios.gestionar" },
    { id: "reportes", t: "Cobranzas y reportes", fn: vistaReportes },
    { id: "auditoria", t: "Auditoría", fn: vistaAuditoria, perm: "auditoria.ver" },
  ].filter((t) => !t.perm || puede(t.perm));

  $("#tabs").innerHTML = TABS.map((t) => `<button type="button" data-tab="${t.id}">${esc(t.t)}</button>`).join("");
  $("#tabs").addEventListener("click", (e) => { const id = e.target.dataset.tab; if (id) ir(id); });

  async function ir(id) {
    const tab = TABS.find((t) => t.id === id) || TABS[0];
    $$("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab.id));
    history.replaceState(null, "", "#" + tab.id);
    $("#view").innerHTML = '<div class="card muted">Cargando…</div>';
    try { await tab.fn($("#view")); } catch (e) { $("#view").innerHTML = `<div class="alert err">${esc(e.message)}</div>`; }
  }

  // ------------------------------------------------------------------ Inicio
  async function vistaInicio(v) {
    const [d, m] = await Promise.all([api("/api/dashboard"), api("/api/reportes/metricas")]);
    const kpi = (t, n) => `<div class="card"><small>${esc(t)}</small><div class="kpi">${esc(n ?? 0)}</div></div>`;
    v.innerHTML = `
      <h1>Resumen</h1>
      <div class="grid">
        ${kpi("Remesas activas", d.remesas_activas)}
        ${Object.values(ESTATUS).map((l) => kpi(l, d.por_estatus[l] || 0)).join("")}
      </div>
      <h2>Métrica estrella (últimos 7 días)</h2>
      <div class="grid">
        ${kpi("Cambios registrados el mismo día", m.pct_mismo_dia === null ? "—" : m.pct_mismo_dia + " %")}
        ${kpi("Meta", m.meta_pct_mismo_dia + " %")}
        ${kpi("Cambios sin señal sincronizados", m.cambios_sin_senal_sincronizados)}
        ${kpi("Consultas públicas", m.consultas_publicas)}
      </div>
      <h2>Conductores en ruta</h2>
      <div class="card table-wrap">${d.choferes_en_ruta.length ? `<table><tr><th>Conductor</th><th>Facturas</th><th>Cerradas</th><th style="width:40%">Avance</th></tr>
        ${d.choferes_en_ruta.map((c) => `<tr><td>${esc(c.chofer)}</td><td>${c.facturas}</td><td>${c.cerradas}</td>
        <td><div class="progress"><span style="width:${Math.round(100 * c.cerradas / Math.max(1, c.facturas))}%"></span></div></td></tr>`).join("")}</table>`
        : '<span class="muted">No hay remesas activas.</span>'}</div>`;
  }

  // ------------------------------------------------------------------ Cargar REMESA
  async function vistaCargar(v) {
    v.innerHTML = `
      <h1>Cargar hoja REMESA</h1>
      <form id="up" class="card stack">
        <div><label for="arch">Archivo Excel (.xlsx)</label><input id="arch" type="file" accept=".xlsx,.xlsm" required></div>
        <div id="hojaBox" class="hidden"><label for="hoja">Hoja</label><select id="hoja"></select></div>
        <div class="row"><button class="primary" type="submit" id="btnAn">Analizar</button>
        <small class="muted">Nada se guarda hasta que usted confirme el resumen.</small></div>
      </form>
      <div id="res" class="stack" style="margin-top:16px"></div>
      <h2>Cargas recientes</h2><div id="hist" class="card table-wrap"></div>`;
    // El Excel se lee en el navegador y solo se envían los valores de la hoja (límite de 4,5 MB en Vercel).
    let libro = null;
    $("#arch").addEventListener("change", async () => {
      libro = null;
      const f = $("#arch").files[0];
      if (!f) return;
      $("#res").innerHTML = '<div class="card muted">Abriendo el libro…</div>';
      try {
        libro = await XlsxLite.open(f);
        const det = await libro.detectRemesaSheet();
        $("#hoja").innerHTML = libro.sheetNames.map((h) => `<option ${h === det ? "selected" : ""}>${esc(h)}</option>`).join("");
        $("#hojaBox").classList.remove("hidden");
        $("#res").innerHTML = det ? `<div class="alert ok">Hoja de remesas detectada: «${esc(det)}». Pulse Analizar.</div>`
          : '<div class="alert warn">No se detectó automáticamente la hoja de remesas: elíjala en la lista.</div>';
      } catch (ex) {
        $("#res").innerHTML = `<div class="alert warn">No se pudo leer el libro en el navegador (${esc(ex.message)}). Se enviará el archivo completo.</div>`;
      }
    });
    $("#up").addEventListener("submit", async (e) => {
      e.preventDefault();
      const f = $("#arch").files[0];
      if (!f) return;
      $("#btnAn").disabled = true;
      $("#res").innerHTML = '<div class="card muted">Leyendo el archivo… (los libros grandes pueden tardar unos segundos)</div>';
      try {
        let imp;
        if (libro) {
          const hoja = $("#hoja").value;
          const filas = await libro.readSheet(hoja);
          const body = await XlsxLite.gzipJson({ archivo: f.name, hoja, hojas: libro.sheetNames, sha256: await libro.sha256(), filas });
          imp = await api("/api/importaciones/filas", { method: "POST", body });
        } else {
          if (f.size > 4.4 * 1024 * 1024) throw new Error("El archivo es demasiado grande para enviarlo completo. Use un navegador actualizado (Chrome, Edge, Firefox).");
          const fd = new FormData();
          fd.append("archivo", f);
          if (!$("#hojaBox").classList.contains("hidden") && $("#hoja").value) fd.append("hoja", $("#hoja").value);
          imp = await api("/api/importaciones", { method: "POST", body: fd });
        }
        mostrarResumen(imp);
      } catch (ex) {
        $("#res").innerHTML = `<div class="alert err">${esc(ex.message)}</div>`;
      } finally { $("#btnAn").disabled = false; }
    });
    cargarHistorial();
  }

  async function cargarHistorial() {
    const lista = await api("/api/importaciones?limite=15");
    $("#hist").innerHTML = lista.length ? `<table><tr><th>#</th><th>Archivo</th><th>Hoja</th><th>Estado</th><th>Fecha</th><th>Resultado</th></tr>
      ${lista.map((i) => `<tr><td>${i.id}</td><td>${esc(i.archivo_nombre)}</td><td>${esc(i.hoja)}</td><td>${esc(i.estado)}</td>
      <td>${esc(fmtFechaHora(i.created_at))}</td><td>${i.resultado ? `${i.resultado.facturas_creadas} facturas, ${i.resultado.remesas_creadas} remesas` : ""}</td></tr>`).join("")}</table>`
      : '<span class="muted">Sin cargas todavía.</span>';
  }

  function mostrarResumen(imp) {
    const r = imp.resumen, t = r.totales;
    const hojaSel = $("#hoja");
    hojaSel.innerHTML = r.hojas_disponibles.map((h) => `<option ${h === r.hoja ? "selected" : ""}>${esc(h)}</option>`).join("");
    $("#hojaBox").classList.remove("hidden");
    const kpi = (tt, n, cls = "") => `<div class="card"><small>${esc(tt)}</small><div class="kpi ${cls}">${esc(n)}</div></div>`;
    const avisos = r.avisos;
    $("#res").innerHTML = `
      <div class="card stack">
        <div class="row between"><h2 style="margin:0">Resumen de «${esc(r.archivo)}» · hoja «${esc(r.hoja)}»</h2>
        <small>${r.filas_leidas} filas leídas</small></div>
        <div class="grid">
          ${kpi("Remesas en el archivo", t.remesas)}${kpi("Remesas nuevas", t.remesas_nuevas)}
          ${kpi("Facturas nuevas", t.facturas_nuevas)}${kpi("Ya cargadas", t.facturas_ya_cargadas)}
          ${kpi("En otra remesa (se omiten)", t.facturas_en_otra_remesa, t.facturas_en_otra_remesa ? "lvl-advertencia" : "")}
          ${kpi("Choferes sin registrar", t.choferes_no_registrados, t.choferes_no_registrados ? "lvl-advertencia" : "")}
        </div>
        ${imp.revision_ia ? `<div class="alert"><strong>Revisión asistida (IA)</strong><div style="white-space:pre-wrap">${esc(imp.revision_ia)}</div></div>` : ""}
        ${Object.keys(r.mapeo_ia || {}).length ? `<div class="alert warn">Columnas asociadas por IA: ${Object.entries(r.mapeo_ia).map(([k, c]) => `«${esc(k)}» → ${esc(c)}`).join(", ")}</div>` : ""}
      </div>
      <div class="card">
        <div class="row between"><h2 style="margin:0">Avisos (${avisos.length})</h2>
          <select id="fNivel" style="width:auto"><option value="">Todos</option><option value="error">Errores</option>
          <option value="advertencia">Advertencias</option><option value="info">Información</option></select></div>
        <div class="table-wrap" style="max-height:320px;overflow:auto"><table id="tAvisos"></table></div>
      </div>
      <div class="card table-wrap">
        <h2 style="margin-top:0">Choferes</h2>
        <table><tr><th>Cédula</th><th>Nombre</th><th>Placa</th><th>Remesas</th><th>Facturas nuevas</th><th>Registrado</th></tr>
        ${r.choferes.map((c) => `<tr><td class="mono">${esc(c.cedula)}</td><td>${esc(c.nombre)}</td><td>${esc(c.placa || "")}</td>
          <td>${c.remesas}</td><td>${c.facturas_nuevas}</td><td>${c.registrado ? "Sí" : '<span class="lvl-advertencia">No</span>'}</td></tr>`).join("")}</table>
      </div>
      <div class="card stack">
        <div class="row between"><h2 style="margin:0">Remesas a cargar</h2>
          <div class="row"><label for="fDesde" style="margin:0">Solo desde</label><input id="fDesde" type="date" style="width:auto">
          <button type="button" class="small" id="selSug">Sugeridas</button><button type="button" class="small" id="selNada">Ninguna</button></div></div>
        <div class="table-wrap" style="max-height:420px;overflow:auto"><table>
          <tr><th></th><th>Remesa</th><th>Fecha</th><th>Chofer</th><th>Destino</th><th>Empresa</th><th>Facturas</th><th>Nuevas</th><th>Estado</th></tr>
          ${r.remesas.map((m) => `<tr>
            <td>${m.estado !== "excluida" ? `<input type="checkbox" data-rem="${esc(m.numero)}" data-fecha="${esc(m.fecha_referencia || "")}" data-sug="${m.seleccion_sugerida ? 1 : 0}" ${m.seleccion_sugerida ? "checked" : ""}>` : ""}</td>
            <td class="mono">${esc(m.numero || "-")}${m.numero_generado ? ' <small class="lvl-advertencia">(generado)</small>' : ""}</td>
            <td>${esc(fmtFecha(m.fecha_referencia))}</td><td>${esc(m.chofer_nombre || "")}${m.chofer_registrado ? "" : ' <small class="lvl-advertencia">sin registrar</small>'}</td>
            <td>${esc(m.destino || "")}</td><td>${esc(m.empresa || "")}</td><td>${m.facturas}</td><td>${m.facturas_nuevas}</td>
            <td>${m.estado === "excluida" ? '<span class="lvl-error">excluida</span>' : esc(m.estado)}</td></tr>`).join("")}
        </table></div>
        ${puede("conductores.crear") ? `<div class="row"><input type="checkbox" id="regCh"><label for="regCh" style="margin:0">Registrar automáticamente los choferes nuevos (se generan claves temporales)</label></div>`
          : '<p class="muted" style="margin:0">Los choferes sin registrar deben darse de alta antes (su rol no crea conductores).</p>'}
        <div id="confErr" class="alert err hidden"></div>
        <div class="row"><button type="button" class="primary" id="btnConf">Confirmar y cargar <span id="nSel"></span></button>
          <button type="button" id="btnDesc">Descartar</button></div>
      </div>`;

    const pintarAvisos = () => {
      const n = $("#fNivel").value;
      const lista = avisos.filter((a) => !n || a.nivel === n);
      $("#tAvisos").innerHTML = `<tr><th>Nivel</th><th>Fila</th><th>Remesa</th><th>Detalle</th></tr>` +
        lista.map((a) => `<tr><td class="lvl-${a.nivel}">${esc(a.nivel)}</td><td>${esc(a.fila ?? "")}</td><td class="mono">${esc(a.remesa || "")}</td><td>${esc(a.mensaje)}</td></tr>`).join("");
    };
    pintarAvisos();
    $("#fNivel").onchange = pintarAvisos;
    const checks = () => $$("[data-rem]");
    const contar = () => { $("#nSel").textContent = `(${checks().filter((c) => c.checked).length})`; };
    $("#res").addEventListener("change", (e) => { if (e.target.dataset.rem !== undefined) contar(); });
    $("#selSug").onclick = () => { checks().forEach((c) => { c.checked = c.dataset.sug === "1"; }); contar(); };
    $("#selNada").onclick = () => { checks().forEach((c) => { c.checked = false; }); contar(); };
    $("#fDesde").onchange = () => {
      const d = $("#fDesde").value;
      checks().forEach((c) => { c.checked = c.dataset.sug === "1" && (!d || (c.dataset.fecha && c.dataset.fecha >= d)); });
      contar();
    };
    contar();
    $("#btnDesc").onclick = async () => {
      await api(`/api/importaciones/${imp.id}/descartar`, { method: "POST" });
      $("#res").innerHTML = '<div class="alert">Carga descartada.</div>'; cargarHistorial();
    };
    $("#btnConf").onclick = async () => {
      const sel = checks().filter((c) => c.checked).map((c) => c.dataset.rem);
      if (!sel.length) { $("#confErr").textContent = "Seleccione al menos una remesa"; $("#confErr").classList.remove("hidden"); return; }
      $("#btnConf").disabled = true;
      try {
        const out = await api(`/api/importaciones/${imp.id}/confirmar`, { method: "POST", body: { remesas: sel, registrar_choferes: !!($("#regCh") && $("#regCh").checked) } });
        $("#res").innerHTML = `<div class="alert ok">Carga completada: ${out.remesas_creadas} remesas nuevas, ${out.facturas_creadas} facturas en estatus Recibida
          (${out.facturas_omitidas} omitidas).${out.remesas_excluidas.length ? ` Remesas excluidas por chofer sin registrar: ${esc(out.remesas_excluidas.join(", "))}.` : ""}</div>`;
        mostrarCredenciales(out.choferes_registrados, "Choferes registrados");
        cargarHistorial();
      } catch (ex) {
        $("#confErr").textContent = ex.message; $("#confErr").classList.remove("hidden");
      } finally { const b = $("#btnConf"); if (b) b.disabled = false; }
    };
  }

  // ------------------------------------------------------------------ Remesas
  async function vistaRemesas(v) {
    v.innerHTML = `<h1>Remesas</h1>
      <form id="fr" class="card row">
        <input name="q" placeholder="Número, chofer, destino o placa" class="grow" style="flex:1 1 200px">
        <select name="estado" style="width:auto"><option value="activas">Activas</option><option value="completas">Completas</option><option value="todas">Todas</option></select>
        <input type="date" name="desde" style="width:auto" aria-label="Desde"><input type="date" name="hasta" style="width:auto" aria-label="Hasta">
        <button class="primary" type="submit">Filtrar</button></form>
      <div id="tr" class="card table-wrap" style="margin-top:12px"></div>`;
    const cargar = async (offset = 0) => {
      const p = new URLSearchParams([...new FormData($("#fr"))].filter(([, x]) => x));
      p.set("limit", 50); p.set("offset", offset);
      const r = await api("/api/remesas?" + p);
      $("#tr").innerHTML = r.items.length ? `<table><tr><th>Remesa</th><th>Fecha carga</th><th>Chofer</th><th class="hide-sm">Placa</th><th class="hide-sm">Destino</th><th>Facturas</th><th style="min-width:120px">Avance</th><th></th></tr>
        ${r.items.map((m) => `<tr><td class="mono">${esc(m.numero)}</td><td>${esc(fmtFechaHora(m.created_at))}</td><td>${esc(m.chofer_nombre || "")}</td>
        <td class="hide-sm">${esc(m.placa || "")}</td><td class="hide-sm">${esc(m.destino || "")}</td><td>${m.total_facturas}</td>
        <td><div class="progress"><span style="width:${Math.round(m.progreso * 100)}%"></span></div><small>${Math.round(m.progreso * 100)} %</small></td>
        <td><button type="button" class="small" data-ver="${m.id}">Ver</button></td></tr>`).join("")}</table>
        ${paginador(r.total, offset)}` : '<span class="muted">Sin resultados.</span>';
    };
    $("#fr").addEventListener("submit", (e) => { e.preventDefault(); cargar(); });
    $("#tr").addEventListener("click", (e) => {
      if (e.target.dataset.ver) verRemesa(Number(e.target.dataset.ver), () => cargar());
      if (e.target.dataset.pag) cargar(Number(e.target.dataset.pag));
    });
    await cargar();
  }

  function paginador(total, offset, size = 50) {
    if (total <= size) return `<small class="muted">${total} resultado(s)</small>`;
    return `<div class="row" style="margin-top:8px"><small class="muted">${offset + 1}–${Math.min(offset + size, total)} de ${total}</small>
      ${offset > 0 ? `<button type="button" class="small" data-pag="${offset - size}">Anterior</button>` : ""}
      ${offset + size < total ? `<button type="button" class="small" data-pag="${offset + size}">Siguiente</button>` : ""}</div>`;
  }

  async function verRemesa(id, alCambiar) {
    const r = await api("/api/remesas/" + id);
    const REASIGNAR = puede("remesas.reasignar"), ELIMINAR = puede("remesas.eliminar");
    const conductores = REASIGNAR ? await api("/api/admin/conductores") : [];
    abrirDialogo(`
      <h2 style="margin-top:0">Remesa ${esc(r.numero)}</h2>
      <div class="grid">
        <div><small>Chofer</small><div>${esc(r.chofer_nombre || "")}</div>${r.chofer_cedula ? `<small>C.I. ${esc(r.chofer_cedula)} · ${esc(r.chofer_telefono || "")}</small>` : ""}</div>
        <div><small>Placa</small><div>${esc(r.placa || "")}</div></div>
        <div><small>Destino</small><div>${esc(r.destino || "")}</div></div>
        <div><small>Empresa</small><div>${esc(r.empresa || "")}</div></div>
      </div>
      <div class="table-wrap"><table><tr><th>Factura</th><th>Cliente</th><th class="hide-sm">Vendedor</th><th class="hide-sm">Total</th><th>Estatus</th><th>Fecha</th></tr>
      ${r.facturas.map((f) => `<tr><td class="mono"><a href="#" data-fact="${f.id}">${esc(f.numero)}</a></td><td>${esc(f.cliente || "")}</td><td class="hide-sm">${esc(f.cod_vendedor || "")}</td>
        <td class="hide-sm">${fmtMonto(f.total_fact)}</td><td>${badge(f.estatus)}</td><td><small>${esc(fmtFechaHora(f.estatus_at))}</small></td></tr>`).join("")}</table></div>
      ${REASIGNAR ? `<div class="row"><label for="reas" style="margin:0">Reasignar a</label><select id="reas" style="width:auto">
        ${conductores.map((c) => `<option value="${c.id}" ${c.id === r.conductor_id ? "selected" : ""}>${esc(c.nombre)}</option>`).join("")}</select>
        <button type="button" class="small" id="btnReas">Reasignar</button></div>` : ""}
      <div id="dlgErr" class="alert err hidden"></div>`,
      `${ELIMINAR ? '<button type="button" class="danger" id="btnDelRem">Eliminar remesa</button>' : ""}
       <button type="button" id="btnXls">Excel Cobranzas</button><button type="submit" class="primary">Cerrar</button>`, null);
    $("#btnXls").onclick = () => TL.download(`/api/reportes/cobranzas.xlsx?remesa_ids=${r.id}`, `Remesa_${r.numero}.xlsx`).catch((e) => toast(e.message));
    $("#dlgBody").addEventListener("click", (e) => {
      const fid = e.target.dataset.fact;
      if (fid) { e.preventDefault(); dlg.close(); verFactura(Number(fid), alCambiar); }
    });
    if (REASIGNAR) {
      $("#btnReas").onclick = async () => {
        await api(`/api/remesas/${r.id}/reasignar`, { method: "POST", body: { conductor_id: Number($("#reas").value) } });
        toast("Remesa reasignada"); dlg.close(); alCambiar && alCambiar();
      };
    }
    if (ELIMINAR) {
      $("#btnDelRem").onclick = async () => {
        if (!confirm(`¿Eliminar la remesa ${r.numero} con sus ${r.facturas.length} facturas e historial? No se puede deshacer.`)) return;
        await api(`/api/remesas/${r.id}`, { method: "DELETE" });
        toast("Remesa eliminada"); dlg.close(); alCambiar && alCambiar();
      };
    }
  }

  // ------------------------------------------------------------------ Facturas
  async function vistaFacturas(v) {
    v.innerHTML = `<h1>Facturas</h1>
      <form id="ff" class="card row">
        <input name="q" placeholder="Factura, pedido, tracking o cliente" class="grow" style="flex:1 1 220px">
        <select name="estatus" style="width:auto"><option value="">Todos los estatus</option>${Object.entries(ESTATUS).map(([k, t]) => `<option value="${k}">${t}</option>`).join("")}</select>
        <input name="cod_vendedor" placeholder="Cod. vendedor" style="width:140px">
        <input type="date" name="desde" style="width:auto" aria-label="Desde"><input type="date" name="hasta" style="width:auto" aria-label="Hasta">
        <button class="primary" type="submit">Buscar</button></form>
      <div id="tf" class="card table-wrap" style="margin-top:12px"></div>`;
    const cargar = async (offset = 0) => {
      const p = new URLSearchParams([...new FormData($("#ff"))].filter(([, x]) => x));
      p.set("limit", 50); p.set("offset", offset);
      const r = await api("/api/facturas?" + p);
      $("#tf").innerHTML = r.items.length ? `<table><tr><th>Factura</th><th>Pedido</th><th>Cliente</th><th class="hide-sm">Remesa</th><th class="hide-sm">Chofer</th><th>Estatus</th><th>Fecha</th></tr>
        ${r.items.map((f) => `<tr><td class="mono"><a href="#" data-fact="${f.id}">${esc(f.numero)}</a></td><td class="mono">${esc(f.pedido || "")}</td><td>${esc(f.cliente || "")}</td>
        <td class="hide-sm mono">${esc(f.remesa_numero || "")}</td><td class="hide-sm">${esc(f.conductor_nombre || "")}</td><td>${badge(f.estatus)}</td><td><small>${esc(fmtFechaHora(f.estatus_at))}</small></td></tr>`).join("")}</table>
        ${paginador(r.total, offset)}` : '<span class="muted">Sin resultados.</span>';
    };
    $("#ff").addEventListener("submit", (e) => { e.preventDefault(); cargar(); });
    $("#tf").addEventListener("click", (e) => {
      if (e.target.dataset.fact) { e.preventDefault(); verFactura(Number(e.target.dataset.fact), () => cargar()); }
      if (e.target.dataset.pag) cargar(Number(e.target.dataset.pag));
    });
    await cargar();
  }

  async function verFactura(id, alCambiar) {
    const f = await api("/api/facturas/" + id);
    const ORIG = { importacion: "Carga REMESA", online: "App conductor", offline: "App conductor (sin señal)", admin: "Corrección manual" };
    abrirDialogo(`
      <div class="row between"><h2 style="margin:0" class="mono">${esc(f.numero)}</h2>${badge(f.estatus)}</div>
      <div class="grid">
        <div><small>Cliente</small><div>${esc(f.cliente || "")}</div></div>
        <div><small>Pedido</small><div class="mono">${esc(f.pedido || "")}</div></div>
        <div><small>Tracking</small><div class="mono">${esc(f.tracking || "—")}</div></div>
        <div><small>Remesa</small><div class="mono">${esc(f.remesa_numero || "")}</div></div>
        <div><small>Vendedor</small><div>${esc(f.cod_vendedor || "")}</div></div>
        <div><small>Total factura / neto</small><div>${fmtMonto(f.total_fact)} / ${fmtMonto(f.total_neto)}</div></div>
        <div><small>Fechas fac / alm / rec</small><div>${esc(fmtFecha(f.fecha_fac))} · ${esc(fmtFecha(f.fecha_alm))} · ${esc(fmtFecha(f.fecha_rec))}</div></div>
        <div><small>Bultos</small><div>${esc(f.bultos ?? "")}</div></div>
      </div>
      ${f.comentario ? `<div><small>Comentario</small><div>${esc(f.comentario)}</div></div>` : ""}
      <h3>Historial</h3>
      <ul class="timeline">${f.eventos.map((e) => `<li class="${e.aplicado ? "" : "muted"}">
        <strong>${esc(ESTATUS[e.estatus])}</strong> · ${esc(fmtFechaHora(e.ocurrido_at))}
        <small> · ${esc(ORIG[e.origen] || e.origen)}${e.usuario_nombre ? " · " + esc(e.usuario_nombre) : ""}${e.aplicado ? "" : " · llegó tarde, solo historial"}</small>
        ${e.motivo ? `<div><small>Motivo: ${esc(e.motivo)}</small></div>` : ""}
        ${e.foto_id ? `<div><img class="thumb" data-foto="${esc(e.foto_id)}" alt="Foto de la factura"></div>` : ""}</li>`).join("")}</ul>
      ${puede("facturas.estatus.corregir") ? `<h3>Corregir estatus</h3><div class="row">
        <select id="nuevoEst" style="width:auto">${Object.entries(ESTATUS).map(([k, t]) => `<option value="${k}" ${k === f.estatus ? "selected" : ""}>${t}</option>`).join("")}</select>
        <input id="motivoAdm" placeholder="Motivo (obligatorio si retrocede)" class="grow" style="flex:1 1 200px">
        <button type="button" class="small" id="btnEst">Aplicar</button></div>` : ""}
      <div id="dlgErr" class="alert err hidden"></div>`, `<button type="submit" class="primary">Cerrar</button>`, null);
    // Las fotos requieren el token: se descargan con fetch y se muestran como blob
    for (const img of $$("img[data-foto]", $("#dlgBody"))) {
      api("/api/fotos/" + img.dataset.foto, { raw: true }).then((r) => r.blob())
        .then((b) => { img.src = URL.createObjectURL(b); }).catch(() => { img.alt = "Foto no disponible"; });
    }
    if (puede("facturas.estatus.corregir")) {
      $("#btnEst").onclick = async () => {
        try {
          await api(`/api/facturas/${f.id}/estatus`, { method: "POST", body: { estatus: $("#nuevoEst").value, motivo: $("#motivoAdm").value || null } });
          toast("Estatus actualizado"); dlg.close(); alCambiar && alCambiar();
        } catch (e) { $("#dlgErr").textContent = e.message; $("#dlgErr").classList.remove("hidden"); }
      };
    }
  }

  // ------------------------------------------------------------------ Catálogos (CRUD genérico)
  async function vistaCrud(v, cfg) {
    v.innerHTML = `<div class="row between"><h1 style="margin:0">${esc(cfg.titulo)}</h1>
      <div class="row">${cfg.extraBotones || ""}${(cfg.puedeCrear ?? PUEDE_EDITAR) ? `<button type="button" class="primary" id="btnNuevo">Nuevo</button>` : ""}</div></div>
      <input id="filtro" type="search" placeholder="Filtrar…" style="margin:12px 0">
      <div id="tbl" class="card table-wrap"></div>`;
    let items = [];
    const pintar = () => {
      const q = $("#filtro").value.toLowerCase();
      const ver = items.filter((i) => !q || JSON.stringify(i).toLowerCase().includes(q));
      $("#tbl").innerHTML = ver.length ? `<table><tr>${cfg.cols.map((c) => `<th>${esc(c[1])}</th>`).join("")}<th></th></tr>
        ${ver.map((i) => `<tr>${cfg.cols.map(([k]) => `<td>${cfg.fmt && cfg.fmt[k] ? cfg.fmt[k](i[k], i) : esc(i[k] ?? "")}</td>`).join("")}
        <td class="row">${(cfg.acciones || []).map((a) => `<button type="button" class="small ${a.cls || ""}" data-acc="${a.id}" data-key="${esc(i[cfg.key])}">${esc(a.t)}</button>`).join("")}</td></tr>`).join("")}</table>
        <small class="muted">${ver.length} registro(s)</small>` : '<span class="muted">Sin registros.</span>';
    };
    const recargar = async () => { items = await api(cfg.url); pintar(); };
    $("#filtro").addEventListener("input", pintar);
    $("#tbl").addEventListener("click", async (e) => {
      const b = e.target.closest("button[data-acc]");
      if (!b) return;
      const item = items.find((i) => String(i[cfg.key]) === b.dataset.key);
      const acc = cfg.acciones.find((a) => a.id === b.dataset.acc);
      try { await acc.fn(item, recargar); } catch (ex) { toast(ex.message); }
    });
    const nuevo = $("#btnNuevo");
    if (nuevo) nuevo.onclick = () => cfg.nuevo(recargar);
    if (cfg.alMontar) cfg.alMontar(recargar);
    await recargar();
  }

  function subirCatalogo(url, titulo, extra) {
    return (recargar) => {
      abrirDialogo(`<h2 style="margin-top:0">${esc(titulo)}</h2><div><label for="catF">Archivo Excel</label><input id="catF" name="archivo" type="file" accept=".xlsx,.xlsm" required></div>
        ${extra || ""}<div id="dlgErr" class="alert err hidden"></div>`,
      `<button type="button" data-cerrar>Cancelar</button><button type="submit" class="primary">Cargar</button>`, async (fd) => {
        const r = await api(url, { method: "POST", body: fd });
        toast(`${r.creados} creados, ${r.actualizados} actualizados`);
        await recargar();
        if (r.credenciales && r.credenciales.length) { setTimeout(() => mostrarCredenciales(r.credenciales, "Conductores creados"), 50); }
      });
    };
  }

  function vistaConductores(v) {
    const campos = (c = {}) => [
      { name: "cedula", label: "Cédula", value: c.cedula, required: true, readonly: !!c.id },
      { name: "nombre", label: "Nombre", value: c.nombre, required: true },
      { name: "telefono", label: "Teléfono", value: c.telefono },
      { name: "placa", label: "Placa habitual", value: c.placa },
      ...(c.id ? [{ name: "activo", label: "Activo", type: "checkbox", value: c.activo }] :
        [{ name: "clave", label: "Clave inicial (vacío = se genera una temporal)", type: "password", min: 6 }]),
    ];
    const cargarPlacas = (recargar) => {
      abrirDialogo(`<h2 style="margin-top:0">Cargar choferes y camiones (hoja PLACAS)</h2>
        <div><label for="catF">Archivo Excel (por ejemplo REMESA.xlsx)</label><input id="catF" type="file" accept=".xlsx,.xlsm" required></div>
        <div><label for="hojaP">Hoja</label><input id="hojaP" value="PLACAS" required></div><div id="dlgErr" class="alert err hidden"></div>`,
      `<button type="button" data-cerrar>Cancelar</button><button type="submit" class="primary">Cargar</button>`, async () => {
        const libro = await XlsxLite.open($("#catF").files[0]);
        const buscada = XlsxLite.norm($("#hojaP").value);
        const hoja = libro.sheetNames.find((n) => XlsxLite.norm(n) === buscada);
        if (!hoja) throw new Error(`El libro no tiene la hoja «${$("#hojaP").value}». Hojas: ${libro.sheetNames.join(", ")}`);
        const filas = await libro.readSheet(hoja, { maxCols: 12 });
        const r = await api("/api/admin/catalogos/placas/filas", { method: "POST", body: await XlsxLite.gzipJson({ hoja, filas }) });
        toast(`${r.creados} creados, ${r.actualizados} actualizados`);
        await recargar();
        if (r.credenciales && r.credenciales.length) setTimeout(() => mostrarCredenciales(r.credenciales, "Conductores creados"), 50);
      });
    };
    return vistaCrud(v, {
      titulo: "Conductores", url: "/api/admin/conductores?incluir_inactivos=true", key: "id",
      cols: [["cedula", "Cédula"], ["nombre", "Nombre"], ["telefono", "Teléfono"], ["placa", "Placa"], ["activo", "Activo"]],
      fmt: { activo: (x) => (x ? "Sí" : '<span class="muted">No</span>') },
      puedeCrear: puede("conductores.crear"),
      extraBotones: puede("conductores.crear") && PUEDE_EDITAR ? '<button type="button" id="btnPlacas">Cargar desde Excel</button>' : "",
      alMontar: (recargar) => { const b = $("#btnPlacas"); if (b) b.onclick = () => cargarPlacas(recargar); },
      nuevo: (recargar) => formulario("Nuevo conductor", campos(), async (fd) => {
        const r = await api("/api/admin/conductores", { method: "POST", body: datos(fd, campos()) });
        await recargar();
        if (r.credencial) setTimeout(() => mostrarCredenciales([r.credencial]), 50);
      }),
      acciones: [
        ...(PUEDE_EDITAR ? [{ id: "ed", t: "Editar", fn: (c, recargar) => formulario("Editar conductor", campos(c), async (fd) => {
          const d = datos(fd, campos(c)); delete d.cedula;
          await api(`/api/admin/conductores/${c.id}`, { method: "PATCH", body: d }); await recargar();
        }) }] : []),
        ...(puede("conductores.claves.gestionar") ? [{ id: "cl", t: "Clave", fn: async (c) => {
          dialogoClave(c.nombre, `/api/admin/conductores/${c.id}/clave`);
        } }] : []),
        ...(PUEDE_EDITAR ? [{ id: "del", t: "Eliminar", cls: "danger", fn: async (c, recargar) => {
          if (!confirm(`¿Eliminar a ${c.nombre}? Si tiene remesas se desactiva para conservar el historial.`)) return;
          const r = await api(`/api/admin/conductores/${c.id}`, { method: "DELETE" });
          toast(r.eliminado ? "Conductor eliminado" : "Conductor desactivado (tiene historial)"); await recargar();
        } }] : []),
      ],
    });
  }

  function vistaCamiones(v) {
    const campos = (c = {}) => [
      { name: "placa", label: "Placa", value: c.placa, required: true, readonly: !!c.id },
      { name: "clase", label: "Clase", value: c.clase }, { name: "color", label: "Color", value: c.color },
      { name: "serial", label: "Serial N.I.V.", value: c.serial },
      ...(c.id ? [{ name: "activo", label: "Activo", type: "checkbox", value: c.activo }] : []),
    ];
    return vistaCrud(v, {
      titulo: "Camiones", url: "/api/admin/camiones", key: "id",
      cols: [["placa", "Placa"], ["clase", "Clase"], ["color", "Color"], ["serial", "Serial"], ["activo", "Activo"]],
      fmt: { activo: (x) => (x ? "Sí" : '<span class="muted">No</span>') },
      nuevo: (recargar) => formulario("Nuevo camión", campos(), async (fd) => {
        await api("/api/admin/camiones", { method: "POST", body: datos(fd, campos()) }); await recargar();
      }),
      acciones: PUEDE_EDITAR ? [
        { id: "ed", t: "Editar", fn: (c, recargar) => formulario("Editar camión", campos(c), async (fd) => {
          const d = datos(fd, campos(c)); delete d.placa;
          await api(`/api/admin/camiones/${c.id}`, { method: "PATCH", body: d }); await recargar();
        }) },
        { id: "del", t: "Eliminar", cls: "danger", fn: async (c, recargar) => {
          if (!confirm(`¿Eliminar el camión ${c.placa}?`)) return;
          await api(`/api/admin/camiones/${c.id}`, { method: "DELETE" }); await recargar();
        } },
      ] : [],
    });
  }

  function vistaVendedores(v) {
    const campos = (c = {}) => [
      { name: "codigo", label: "Código", value: c.codigo, required: true, readonly: !!c.codigo },
      { name: "nombre", label: "Nombre", value: c.nombre, required: true },
      { name: "territorio", label: "Territorio", value: c.territorio },
      { name: "email", label: "Correo (para avisos de estatus)", type: "email", value: c.email },
      ...(c.codigo ? [{ name: "activo", label: "Activo", type: "checkbox", value: c.activo }] : []),
    ];
    const cargar = subirCatalogo("/api/admin/catalogos/vendedores", "Cargar Listado de Código de Vendedores");
    return vistaCrud(v, {
      titulo: "Vendedores", url: "/api/admin/vendedores", key: "codigo",
      cols: [["codigo", "Código"], ["nombre", "Nombre"], ["territorio", "Territorio"], ["email", "Correo"], ["activo", "Activo"]],
      fmt: { activo: (x) => (x ? "Sí" : '<span class="muted">No</span>') },
      extraBotones: PUEDE_EDITAR ? '<button type="button" id="btnVend">Cargar desde Excel</button>' : "",
      alMontar: (recargar) => { const b = $("#btnVend"); if (b) b.onclick = () => cargar(recargar); },
      nuevo: (recargar) => formulario("Nuevo vendedor", campos(), async (fd) => {
        await api("/api/admin/vendedores", { method: "POST", body: datos(fd, campos()) }); await recargar();
      }),
      acciones: PUEDE_EDITAR ? [
        { id: "ed", t: "Editar", fn: (c, recargar) => formulario("Editar vendedor", campos(c), async (fd) => {
          const d = datos(fd, campos(c)); delete d.codigo;
          await api(`/api/admin/vendedores/${encodeURIComponent(c.codigo)}`, { method: "PATCH", body: d }); await recargar();
        }) },
        { id: "del", t: "Eliminar", cls: "danger", fn: async (c, recargar) => {
          if (!confirm(`¿Eliminar al vendedor ${c.codigo}?`)) return;
          await api(`/api/admin/vendedores/${encodeURIComponent(c.codigo)}`, { method: "DELETE" }); await recargar();
        } },
      ] : [],
    });
  }

  function vistaUsuarios(v) {
    const roles = [["transportista", "Transportista"], ["cobranzas", "Cobranzas"], ["supervisor", "Supervisor"]];
    if (puede("conductores.crear")) roles.push(["conductor", "Conductor"]);
    const campos = (u = {}) => u.id ? [
      { name: "nombre", label: "Nombre", value: u.nombre, required: true },
      ...(u.rol !== "conductor" ? [{ name: "rol", label: "Rol", type: "select", options: roles.filter((r) => r[0] !== "conductor"), value: u.rol }] : []),
      { name: "email", label: "Correo", type: "email", value: u.email },
      { name: "activo", label: "Activo", type: "checkbox", value: u.activo },
    ] : [
      { name: "rol", label: "Rol", type: "select", options: roles, value: "transportista" },
      { name: "username", label: "Usuario (no aplica a Conductor: entra con su cédula)" },
      { name: "nombre", label: "Nombre", required: true },
      { name: "email", label: "Correo", type: "email" },
      { name: "cedula", label: "Cédula (solo Conductor)" },
      { name: "telefono", label: "Teléfono (solo Conductor)" },
      { name: "clave", label: "Clave inicial (vacío = se genera una temporal)", type: "password", min: 6 },
    ];
    return vistaCrud(v, {
      titulo: "Usuarios", url: "/api/admin/usuarios?incluir_conductores=true", key: "id", puedeCrear: true,
      cols: [["username", "Usuario"], ["nombre", "Nombre"], ["rol", "Rol"], ["email", "Correo"], ["activo", "Activo"]],
      fmt: { rol: (x) => esc(ROLES[x] || x), activo: (x) => (x ? "Sí" : '<span class="muted">No</span>') },
      nuevo: (recargar) => formulario("Nuevo usuario", campos(), async (fd) => {
        const r = await api("/api/admin/usuarios", { method: "POST", body: datos(fd, campos()) });
        await recargar();
        if (r.credencial) setTimeout(() => mostrarCredenciales([r.credencial]), 50);
      }),
      acciones: [
        { id: "ed", t: "Editar", fn: (u, recargar) => formulario("Editar usuario", campos(u), async (fd) => {
          const d = datos(fd, campos(u)); delete d.username;
          await api(`/api/admin/usuarios/${u.id}`, { method: "PATCH", body: d }); await recargar();
        }) },
        ...(puede("usuarios.claves.gestionar") ? [{ id: "cl", t: "Clave", fn: async (u) => {
          if (u.id === me.id) { toast("Para su propia clave use «Mi clave»"); return; }
          dialogoClave(u.nombre, `/api/admin/usuarios/${u.id}/clave`);
        } }] : []),
        ...(puede("usuarios.credenciales.consultar") ? [{ id: "cr", t: "Estado de clave", fn: async (u) => verCredencial(u) }] : []),
        { id: "del", t: "Eliminar", cls: "danger", fn: async (u, recargar) => {
          if (!confirm(`¿Eliminar el usuario ${u.username}?`)) return;
          await api(`/api/admin/usuarios/${u.id}`, { method: "DELETE" }); await recargar();
        } },
      ],
    });
  }

  // ------------------------------------------------------------------ Claves y auditoría
  function dialogoClave(nombre, url) {
    abrirDialogo(`<h2 style="margin-top:0">Clave de ${esc(nombre)}</h2>
      <p class="muted" style="margin:0">Las claves se guardan cifradas y no pueden consultarse. Puede generar una temporal o fijar una nueva.
        En ambos casos se cierran las sesiones abiertas de ese usuario.</p>
      <div class="row"><input type="radio" name="modo" id="mTemp" value="temp" checked><label for="mTemp" style="margin:0">Generar una clave temporal (recomendado)</label></div>
      <div class="row"><input type="radio" name="modo" id="mFija" value="fija"><label for="mFija" style="margin:0">Fijar esta clave:</label></div>
      <div><input id="cNueva" type="password" minlength="6" autocomplete="new-password" placeholder="Mínimo 6 caracteres"></div>
      <div class="row"><input type="checkbox" id="cCambiar" checked><label for="cCambiar" style="margin:0">Obligar a cambiarla en el próximo ingreso</label></div>
      <div id="dlgErr" class="alert err hidden"></div>`,
    `<button type="button" data-cerrar>Cancelar</button><button type="submit" class="primary">Aplicar</button>`, async () => {
      const fija = $("#mFija").checked;
      const body = fija ? { clave_nueva: $("#cNueva").value, debe_cambiar_clave: $("#cCambiar").checked } : {};
      if (fija && body.clave_nueva.length < 6) throw new Error("La clave debe tener al menos 6 caracteres");
      const r = await api(url, { method: "POST", body });
      if (r.clave_temporal) setTimeout(() => mostrarCredenciales([r], "Clave temporal generada"), 50);
      else toast("Clave actualizada. El usuario deberá entrar con la nueva clave.");
    });
    $("#cNueva").addEventListener("input", () => { $("#mFija").checked = true; });
  }

  async function verCredencial(u) {
    const c = await api(`/api/admin/usuarios/${u.id}/credencial`);
    abrirDialogo(`<h2 style="margin-top:0">Estado de la clave · ${esc(c.nombre)}</h2>
      <table>
        <tr><td>Usuario</td><td class="mono">${esc(c.usuario)}</td></tr>
        <tr><td>Rol</td><td>${esc(ROLES[c.rol] || c.rol)}</td></tr>
        <tr><td>Activo</td><td>${c.activo ? "Sí" : "No"}</td></tr>
        <tr><td>Clave</td><td>${c.tiene_clave ? "Asignada" : "Sin clave"} · cifrado ${esc(c.algoritmo)}</td></tr>
        <tr><td>Debe cambiarla al entrar</td><td>${c.debe_cambiar_clave ? "Sí" : "No"}</td></tr>
        <tr><td>Último cambio</td><td>${esc(fmtFechaHora(c.clave_actualizada_at) || "—")}${c.clave_actualizada_por ? " · por " + esc(c.clave_actualizada_por) : ""}</td></tr>
        <tr><td>Último ingreso</td><td>${esc(fmtFechaHora(c.ultimo_acceso_at) || "Nunca")}</td></tr>
      </table>
      <p class="muted">${esc(c.nota)}</p>`,
    `${puede("usuarios.claves.gestionar") && u.id !== me.id ? '<button type="button" id="btnRest">Restablecer clave</button>' : ""}<button type="submit" class="primary">Cerrar</button>`, null);
    const b = $("#btnRest");
    if (b) b.onclick = () => { dlg.close(); dialogoClave(c.nombre, `/api/admin/usuarios/${u.id}/clave`); };
  }

  async function vistaAuditoria(v) {
    const ACC = {
      usuario_creado: "Usuario creado", conductor_creado: "Conductor creado", usuario_editado: "Usuario editado",
      usuario_eliminado: "Usuario eliminado", clave_cambiada: "Cambió su clave", clave_establecida: "Clave fijada por administrador",
      clave_restablecida: "Clave temporal generada", credencial_consultada: "Consulta de credencial",
    };
    const [eventos, usuarios] = await Promise.all([api("/api/admin/auditoria?limite=300"), api("/api/admin/usuarios?incluir_conductores=true")]);
    const nombre = new Map(usuarios.map((u) => [u.id, `${u.nombre} (${u.username})`]));
    v.innerHTML = `<h1>Auditoría de seguridad</h1>
      <p class="muted">Altas de usuarios y conductores, cambios de rol y de clave. Nunca se registran las claves.</p>
      <div class="card table-wrap">${eventos.length ? `<table><tr><th>Fecha</th><th>Acción</th><th>Quién</th><th>Sobre</th><th class="hide-sm">Detalle</th></tr>
      ${eventos.map((e) => `<tr><td><small>${esc(fmtFechaHora(e.created_at))}</small></td><td>${esc(ACC[e.accion] || e.accion)}</td>
        <td>${esc(nombre.get(e.actor_id) || (e.actor_rol ? "(" + e.actor_rol + ")" : "—"))}</td>
        <td>${esc(nombre.get(e.objetivo_usuario_id) || e.detalle.usuario || e.detalle.cedula || "—")}</td>
        <td class="hide-sm"><small class="mono">${esc(JSON.stringify(e.detalle))}</small></td></tr>`).join("")}</table>` : '<span class="muted">Sin registros.</span>'}</div>`;
  }

  // ------------------------------------------------------------------ Reportes
  async function vistaReportes(v) {
    const cfg = await api("/api/config");
    const hoy = new Date().toISOString().slice(0, 10);
    v.innerHTML = `<h1>Cobranzas y reportes</h1>
      <section class="card stack">
        <h2 style="margin-top:0">Excel de entregas para Cobranzas</h2>
        <p class="muted" style="margin:0">Mismo formato que Libro2, con Cod. Vendedor, estatus y fecha/hora del estatus. Incluye las remesas con facturas cerradas en el rango.</p>
        <div class="row"><label style="margin:0" for="xDesde">Desde</label><input type="date" id="xDesde" value="${hoy}" style="width:auto">
          <label style="margin:0" for="xHasta">Hasta</label><input type="date" id="xHasta" value="${hoy}" style="width:auto">
          <input type="checkbox" id="xFin"><label for="xFin" style="margin:0">Solo facturas con estatus final</label></div>
        <div class="row"><button type="button" class="primary" id="btnXls">Descargar Excel</button>
          ${puede("notificaciones.enviar") ? `<button type="button" id="btnMailCob" ${cfg.correo ? "" : "disabled"}>Enviar por correo a Cobranzas</button>` : ""}</div>
      </section>
      ${puede("notificaciones.enviar") ? `<section class="card stack" style="margin-top:12px">
        <h2 style="margin-top:0">Avisar a vendedores</h2>
        <p class="muted" style="margin:0">Cada vendedor recibe solo el estatus de sus facturas (sin montos). Requiere el correo del vendedor en la sección Vendedores.</p>
        <div class="row"><select id="nModo" style="width:auto"><option value="en_curso">Facturas cargadas o en tránsito</option><option value="final">Facturas con estatus final</option></select>
          <label style="margin:0" for="nDesde">Desde</label><input type="date" id="nDesde" value="${hoy}" style="width:auto">
          <label style="margin:0" for="nHasta">Hasta</label><input type="date" id="nHasta" value="${hoy}" style="width:auto"></div>
        <div class="row"><button type="button" id="btnSim">Vista previa</button><button type="button" class="primary" id="btnEnv" ${cfg.correo ? "" : "disabled"}>Enviar correos</button>
          ${cfg.correo ? "" : '<small class="muted">El envío de correos está desactivado (EMAIL_ENABLED). Puede usar la vista previa.</small>'}</div>
        <div id="nOut"></div>
      </section>` : ""}
      <section class="card stack" style="margin-top:12px">
        <h2 style="margin-top:0">Métricas</h2>
        <div class="row"><input type="date" id="mDesde" style="width:auto"><input type="date" id="mHasta" style="width:auto"><button type="button" id="btnMet">Calcular</button></div>
        <div id="mOut"></div>
      </section>`;
    const q = () => `desde=${$("#xDesde").value}&hasta=${$("#xHasta").value}&solo_finales=${$("#xFin").checked}`;
    $("#btnXls").onclick = () => TL.download("/api/reportes/cobranzas.xlsx?" + q(), "Entregas_Cobranzas.xlsx").catch((e) => toast(e.message));
    if ($("#btnMailCob")) $("#btnMailCob").onclick = async () => {
      try {
        const r = await api("/api/reportes/notificar/cobranzas", { method: "POST", body: { desde: $("#xDesde").value, hasta: $("#xHasta").value, solo_finales: $("#xFin").checked } });
        toast(`Enviado a ${r.para.join(", ")}: ${r.facturas} facturas`);
      } catch (e) { toast(e.message); }
    };
    const notificar = async (simular) => {
      const r = await api("/api/reportes/notificar/vendedores", { method: "POST", body: { modo: $("#nModo").value, desde: $("#nDesde").value, hasta: $("#nHasta").value, simular } });
      $("#nOut").innerHTML = `<div class="alert">${r.vendedores} vendedor(es) con facturas · ${r.enviados.length} enviados · sin correo: ${esc(r.sin_correo.join(", ") || "—")}
        ${r.errores.length ? `<div class="lvl-error">Errores: ${esc(r.errores.map((x) => x.codigo + ": " + x.error).join("; "))}</div>` : ""}</div>
        ${r.vista_previa.map((p) => `<details class="card"><summary>${esc(p.codigo)} → ${esc(p.para.join(", "))} · ${esc(p.asunto)}</summary><pre style="white-space:pre-wrap">${esc(p.texto)}</pre></details>`).join("")}`;
    };
    if ($("#btnSim")) {
      $("#btnSim").onclick = () => notificar(true).catch((e) => toast(e.message));
      $("#btnEnv").onclick = () => { if (confirm("¿Enviar los correos a los vendedores?")) notificar(false).catch((e) => toast(e.message)); };
    }
    $("#btnMet").onclick = async () => {
      const p = new URLSearchParams();
      if ($("#mDesde").value) p.set("desde", $("#mDesde").value);
      if ($("#mHasta").value) p.set("hasta", $("#mHasta").value);
      const m = await api("/api/reportes/metricas?" + p);
      $("#mOut").innerHTML = `<table>
        <tr><td>Período</td><td>${esc(fmtFecha(m.desde))} – ${esc(fmtFecha(m.hasta))}</td></tr>
        <tr><td>Cambios de estatus</td><td>${m.cambios_de_estatus}</td></tr>
        <tr><td>% registrados el mismo día (meta ${m.meta_pct_mismo_dia} %)</td><td><strong>${m.pct_mismo_dia ?? "—"} %</strong></td></tr>
        <tr><td>Cambios sin señal sincronizados</td><td>${m.cambios_sin_senal_sincronizados}</td></tr>
        <tr><td>Consultas públicas (encontradas)</td><td>${m.consultas_publicas} (${m.consultas_publicas_encontradas})</td></tr>
        ${Object.entries(m.facturas_por_estatus).map(([k, n]) => `<tr><td>Facturas ${esc(k)}</td><td>${n}</td></tr>`).join("")}</table>`;
    };
    $("#btnMet").click();
  }

  // ------------------------------------------------------------------ sesión
  $("#btnSalir").onclick = () => { TL.clearSession(); location.replace("/"); };
  $("#btnClave").onclick = () => {
    const campos = [{ name: "clave_actual", label: "Clave actual", type: "password", required: true },
      { name: "clave_nueva", label: "Clave nueva (mínimo 6)", type: "password", required: true, min: 6 }];
    formulario("Cambiar mi clave", campos, async (fd) => {
      const r = await api("/api/me/clave", { method: "POST", body: datos(fd, campos) });
      TL.setSession(r.access_token, r.usuario); toast("Clave actualizada");
    });
  };

  ir(location.hash.slice(1) || "inicio");
})();
