"""Hash de claves, tokens JWT y dependencias de autorización por rol."""

from __future__ import annotations

import secrets
import string
from collections.abc import Iterator
from datetime import datetime, timedelta, timezone
from typing import Any

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from tracking.config import Settings, get_settings
from tracking.enums import Rol
from tracking.models import Usuario

_hasher = PasswordHasher()
_bearer = HTTPBearer(auto_error=False)



def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    try:
        return _hasher.verify(hashed, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def needs_rehash(hashed: str) -> bool:
    try:
        return _hasher.check_needs_rehash(hashed)
    except InvalidHashError:
        return True


def generate_temp_password(length: int = 8) -> str:
    # Sin caracteres ambiguos (0/O, 1/l/I) para dictarla por teléfono.
    alphabet = "".join(c for c in string.ascii_letters + string.digits if c not in "0O1lI")
    return "".join(secrets.choice(alphabet) for _ in range(length))


def create_access_token(user: Usuario, settings: Settings) -> tuple[str, datetime]:
    now = datetime.now(timezone.utc)
    if user.rol == Rol.CONDUCTOR.value:
        exp = now + timedelta(days=settings.driver_token_days)
    else:
        exp = now + timedelta(minutes=settings.staff_token_minutes)
    payload: dict[str, Any] = {
        "sub": str(user.id),
        "rol": user.rol,
        "tv": user.token_version,
        "iat": int(now.timestamp()),
        "exp": int(exp.timestamp()),
    }
    token = jwt.encode(payload, settings.secret_key, algorithm=settings.jwt_algorithm)
    return token, exp


def get_db(request: Request) -> Iterator[Session]:
    db: Session = request.app.state.db.session()
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def get_current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> Usuario:
    unauthorized = HTTPException(
        status.HTTP_401_UNAUTHORIZED,
        "Sesión inválida o vencida",
        headers={"WWW-Authenticate": "Bearer"},
    )
    if creds is None:
        raise unauthorized
    try:
        payload = jwt.decode(creds.credentials, settings.secret_key, algorithms=[settings.jwt_algorithm])
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise unauthorized from None
    user = db.get(Usuario, user_id)
    if user is None or not user.activo or user.token_version != payload.get("tv"):
        raise unauthorized
    return user


def client_ip(request: Request, settings: Settings) -> str:
    """IP real del cliente (para límites de intentos/consultas)."""
    if settings.trust_proxy_headers:
        real = request.headers.get("x-real-ip")
        if real:
            return real.strip()
        fwd = request.headers.get("x-forwarded-for")
        if fwd:
            return fwd.split(",")[0].strip()
    return request.client.host if request.client else "?"
