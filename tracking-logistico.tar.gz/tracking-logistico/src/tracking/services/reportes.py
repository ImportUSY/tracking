"""Consultas de reporte: selección para Cobranzas, avisos a vendedores y métricas del PRD."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Sequence
from datetime import date, timedelta
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from tracking.enums import Estatus, OrigenEvento
from tracking.models import ConsultaPublica, EventoEstatus, Factura, Remesa
from tracking.services.timeutil import local_day_bounds, to_local, today_local

FINALES = (Estatus.ENTREGADA.value, Estatus.DEVOLUCION.value)
EN_CURSO = (Estatus.CARGADO.value, Estatus.EN_TRANSITO.value)


def seleccionar_para_cobranzas(
    db: Session,
    remesa_ids: Sequence[int] | None,
    desde: date | None,
    hasta: date | None,
    solo_finales: bool,
) -> list[tuple[Remesa, list[Factura]]]:
    stmt = select(Remesa).options(selectinload(Remesa.facturas)).order_by(Remesa.numero)
    if remesa_ids:
        stmt = stmt.where(Remesa.id.in_(list(remesa_ids)))
    else:
        if desde is None and hasta is None:
            desde = hasta = today_local()
        ini, fin = local_day_bounds(desde, hasta)
        sub = select(Factura.remesa_id).where(Factura.estatus.in_(FINALES))
        if ini:
            sub = sub.where(Factura.estatus_at >= ini)
        if fin:
            sub = sub.where(Factura.estatus_at < fin)
        stmt = stmt.where(Remesa.id.in_(sub))
    salida: list[tuple[Remesa, list[Factura]]] = []
    for remesa in db.scalars(stmt):
        facturas = [f for f in remesa.facturas if not solo_finales or f.estatus in FINALES]
        if facturas:
            salida.append((remesa, facturas))
    return salida


def facturas_por_vendedor(
    db: Session,
    modo: str,
    desde: date | None,
    hasta: date | None,
    remesa_ids: Sequence[int] | None,
) -> dict[str, list[Factura]]:
    estatus = EN_CURSO if modo == "en_curso" else FINALES
    stmt = (
        select(Factura)
        .options(selectinload(Factura.remesa))
        .where(Factura.estatus.in_(estatus), Factura.cod_vendedor.is_not(None))
        .order_by(Factura.cod_vendedor, Factura.numero)
    )
    if remesa_ids:
        stmt = stmt.where(Factura.remesa_id.in_(list(remesa_ids)))
    else:
        if desde is None and hasta is None:
            desde = hasta = today_local()
        ini, fin = local_day_bounds(desde, hasta)
        if ini:
            stmt = stmt.where(Factura.estatus_at >= ini)
        if fin:
            stmt = stmt.where(Factura.estatus_at < fin)
    grupos: dict[str, list[Factura]] = defaultdict(list)
    for f in db.scalars(stmt):
        grupos[f.cod_vendedor or ""].append(f)
    return dict(grupos)


def metricas(db: Session, desde: date | None, hasta: date | None) -> dict[str, Any]:
    """Métrica estrella y de apoyo definidas en la sección 11 del PRD."""
    hasta = hasta or today_local()
    desde = desde or (hasta - timedelta(days=6))
    ini, fin = local_day_bounds(desde, hasta)
    assert ini is not None and fin is not None

    eventos = db.execute(
        select(EventoEstatus.ocurrido_at, EventoEstatus.recibido_at, EventoEstatus.origen)
        .where(
            EventoEstatus.ocurrido_at >= ini,
            EventoEstatus.ocurrido_at < fin,
            EventoEstatus.origen.in_([OrigenEvento.ONLINE.value, OrigenEvento.OFFLINE.value]),
        )
    ).all()
    total = len(eventos)
    mismo_dia = sum(1 for o, r, _ in eventos if to_local(o).date() == to_local(r).date())
    offline = sum(1 for _, _, origen in eventos if origen == OrigenEvento.OFFLINE.value)

    filas = db.execute(select(Factura.estatus, func.count(Factura.id)).group_by(Factura.estatus)).all()
    por_estatus: dict[str, int] = {str(est): int(n) for est, n in filas}
    consultas_total = db.scalar(
        select(func.count(ConsultaPublica.id)).where(
            ConsultaPublica.created_at >= ini, ConsultaPublica.created_at < fin
        )
    ) or 0
    consultas_ok = db.scalar(
        select(func.count(ConsultaPublica.id)).where(
            ConsultaPublica.created_at >= ini, ConsultaPublica.created_at < fin, ConsultaPublica.encontrado
        )
    ) or 0
    return {
        "desde": desde.isoformat(),
        "hasta": hasta.isoformat(),
        "cambios_de_estatus": total,
        "pct_mismo_dia": round(100.0 * mismo_dia / total, 1) if total else None,
        "meta_pct_mismo_dia": 95,
        "cambios_sin_senal_sincronizados": offline,
        "facturas_por_estatus": {Estatus(k).label: v for k, v in por_estatus.items()},
        "consultas_publicas": int(consultas_total),
        "consultas_publicas_encontradas": int(consultas_ok),
    }
