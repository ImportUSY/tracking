"""Excel para Cobranzas con el mismo formato de bloque que 'Libro2' + Cod. Vendedor y estatus.

Columnas B..N idénticas a Libro2 (para que fórmulas o macros existentes sigan funcionando) y
al final: O = Cod. Vendedor, P = Estatus, Q = Fecha/hora del estatus (hora local).
"""

from __future__ import annotations

import io
from collections.abc import Sequence
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from tracking.enums import Estatus
from tracking.models import Factura, Remesa
from tracking.services.timeutil import to_local

THIN = Side(style="thin")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
GRIS = PatternFill("solid", fgColor="D9D9D9")
AZUL = PatternFill("solid", fgColor="DDEBF7")
FILL_ESTATUS = {
    Estatus.ENTREGADA.value: PatternFill("solid", fgColor="C6EFCE"),
    Estatus.DEVOLUCION.value: PatternFill("solid", fgColor="FFC7CE"),
}
FILL_EN_CURSO = PatternFill("solid", fgColor="FFEB9C")

HEADERS = [
    "Factura", "N de Pedido", "Fecha Fac", "Fecha Alm", "Fecha Rec", "Bult", "Total Fact", "%",
    "Total Neto", "F", "Total Flete", "COMENTARIO", "Cod. Vendedor", "Estatus", "Fecha Estatus",
]
WIDTHS = {
    "A": 5.86, "B": 34, "C": 15, "D": 19, "E": 10, "F": 10, "G": 10, "H": 6, "I": 12, "J": 6,
    "K": 12, "L": 6, "M": 11, "N": 26, "O": 13, "P": 13, "Q": 17,
}
SEPARACION = 6
FMT_FECHA = "mm-dd-yy"
FMT_MONTO = "#,##0.00"
FMT_PCT = "0%"


def _font(size: float, bold: bool = False) -> Font:
    return Font(name="Arial", size=size, bold=bold)


def _escribir_bloque(ws: Worksheet, fila: int, remesa: Remesa, facturas: Sequence[Factura]) -> int:
    # Encabezado del bloque (B=2)
    c = ws.cell(fila, 2, "Chofer:")
    c.font, c.fill, c.alignment = _font(11, True), GRIS, Alignment(horizontal="right")
    cedula = remesa.chofer_cedula
    ced = ws.cell(fila, 3, int(cedula) if cedula and cedula.isdigit() else cedula)
    ced.font, ced.number_format = _font(10), "00,000,000"
    nom = ws.cell(fila, 5, remesa.chofer_nombre)
    nom.font, nom.alignment = _font(12), Alignment(horizontal="left")

    c = ws.cell(fila + 1, 2, "Placa:")
    c.font, c.fill, c.alignment = _font(11, True), GRIS, Alignment(horizontal="right")
    p = ws.cell(fila + 1, 3, remesa.placa)
    p.font, p.alignment = _font(11, True), Alignment(horizontal="center")
    ws.cell(fila + 1, 5, "Telf.:").font = _font(11, True)
    t = ws.cell(fila + 1, 6, remesa.chofer_telefono)
    t.font, t.alignment = _font(11, True), Alignment(horizontal="left")

    c = ws.cell(fila + 2, 2, "Destino:")
    c.font, c.fill, c.alignment = _font(11, True), GRIS, Alignment(horizontal="right")
    d = ws.cell(fila + 2, 3, remesa.destino)
    d.font, d.fill, d.alignment = _font(11, True), AZUL, Alignment(horizontal="center")
    for col in range(3, 10):
        ws.cell(fila + 2, col).border = Border(bottom=THIN)
    ws.merge_cells(start_row=fila + 2, start_column=3, end_row=fila + 2, end_column=9)
    n = ws.cell(fila + 2, 12, remesa.numero)
    n.font, n.alignment = _font(8, True), Alignment(horizontal="center")

    # Encabezados de tabla
    h = fila + 3
    ws.row_dimensions[h].height = 30
    cab = ws.cell(h, 2, remesa.empresa)
    cab.font, cab.fill, cab.border = _font(11, True), GRIS, BORDER
    cab.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for i, titulo in enumerate(HEADERS, start=3):
        cell = ws.cell(h, i, titulo)
        cell.font, cell.fill, cell.border = _font(11, True), GRIS, BORDER
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # Filas
    r = h + 1
    primera = r
    for f in facturas:
        valores: list[tuple[object, float, str | None, str]] = [
            (f.cliente, 6, None, "left"),
            (f.numero, 8, None, "center"),
            (f.pedido, 8, None, "center"),
            (f.fecha_fac, 9, FMT_FECHA, "center"),
            (f.fecha_alm, 9, FMT_FECHA, "center"),
            (f.fecha_rec, 9, FMT_FECHA, "center"),
            (f.bultos, 9, None, "center"),
            (float(f.total_fact) if f.total_fact is not None else None, 9, FMT_MONTO, "center"),
            (float(f.porcentaje) if f.porcentaje is not None else None, 8, FMT_PCT, "center"),
            (float(f.total_neto) if f.total_neto is not None else None, 9, FMT_MONTO, "center"),
            (float(f.flete_pct) if f.flete_pct is not None else None, 8, FMT_PCT, "center"),
            (float(f.total_flete) if f.total_flete is not None else None, 9, FMT_MONTO, "center"),
            (f.comentario, 6, None, "left"),
            (f.cod_vendedor, 8, None, "center"),
            (Estatus(f.estatus).label, 8, None, "center"),
            (to_local(f.estatus_at).replace(tzinfo=None) if f.estatus_at else None, 8,
             "dd/mm/yyyy hh:mm", "center"),
        ]
        for i, (valor, size, fmt, align) in enumerate(valores, start=2):
            cell = ws.cell(r, i, valor)
            cell.font, cell.border = _font(size), BORDER
            cell.alignment = Alignment(horizontal=align, vertical="center")
            if fmt:
                cell.number_format = fmt
        ws.cell(r, 16).fill = FILL_ESTATUS.get(f.estatus, FILL_EN_CURSO)
        r += 1
    ultima = r - 1

    # Totales (fórmulas, como en Libro2)
    tot = ws.cell(r, 2, "TOTALES:")
    tot.font, tot.alignment = _font(9, True), Alignment(horizontal="right")
    if facturas:
        for col in (9, 11):
            letra = get_column_letter(col)
            cell = ws.cell(r, col, f"=SUM({letra}{primera}:{letra}{ultima})")
            cell.font, cell.number_format = _font(8, True), FMT_MONTO
            cell.alignment = Alignment(horizontal="center")
        flete = ws.cell(r + 1, 13, f"=SUM(M{primera}:M{ultima})")
        flete.font, flete.number_format, flete.border = _font(8, True), FMT_MONTO, BORDER
        flete.alignment = Alignment(horizontal="center")
    return r + 2 + SEPARACION


def generar_excel_cobranzas(
    remesas: Sequence[tuple[Remesa, Sequence[Factura]]], titulo: str | None = None
) -> bytes:
    wb = Workbook()
    ws = wb.active
    assert ws is not None
    ws.title = "Hoja1"
    for col, w in WIDTHS.items():
        ws.column_dimensions[col].width = w
    fila = 2
    if titulo:
        t = ws.cell(fila, 2, titulo)
        t.font = _font(12, True)
        ws.cell(fila + 1, 2, f"Generado: {datetime.now():%d/%m/%Y %H:%M}").font = _font(8)
    fila = 6
    for remesa, facturas in remesas:
        fila = _escribir_bloque(ws, fila, remesa, facturas)
    ws.sheet_view.zoomScale = 90
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
