"""Administración: conductores, camiones, usuarios, vendedores y carga de catálogos."""

from __future__ import annotations

import io

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from pydantic import ValidationError
from sqlalchemy import exists, func, or_, select
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool

from tracking.api.importaciones import leer_excel, leer_json
from tracking.config import Settings, get_settings
from tracking.enums import Rol
from tracking.models import Camion, Conductor, Factura, Remesa, Usuario, Vendedor
from tracking.schemas import (
    CamionIn,
    CamionOut,
    CamionUpdate,
    ConductorIn,
    ConductorOut,
    ConductorUpdate,
    CredencialTemporal,
    FilasExcelIn,
    UsuarioIn,
    UsuarioOut,
    UsuarioUpdate,
    VendedorIn,
    VendedorOut,
    VendedorUpdate,
)
from tracking.security import (
    STAFF_READ,
    STAFF_WRITE,
    can_see_personal_data,
    generate_temp_password,
    get_db,
    hash_password,
    require_roles,
)
from tracking.services.catalogos import importar_placas, importar_placas_filas, importar_vendedores
from tracking.services.normalize import clean_code, clean_phone
from tracking.services.users import ConflictoDatos, crear_usuario, crear_usuario_conductor

router = APIRouter(prefix="/api/admin", tags=["admin"])


def _conflict(exc: Exception) -> HTTPException:
    return HTTPException(status.HTTP_409_CONFLICT, str(exc))


# ------------------------------------------------------------------ Conductores
def _conductor_out(c: Conductor, viewer: Usuario) -> ConductorOut:
    out = ConductorOut.model_validate(c)
    if not can_see_personal_data(viewer):
        out.cedula = None
        out.telefono = None
    return out


@router.get("/conductores", response_model=list[ConductorOut])
def listar_conductores(
    q: str | None = None,
    incluir_inactivos: bool = False,
    user: Usuario = Depends(require_roles(*STAFF_READ)),
    db: Session = Depends(get_db),
) -> list[ConductorOut]:
    stmt = select(Conductor).order_by(Conductor.nombre)
    if not incluir_inactivos:
        stmt = stmt.where(Conductor.activo.is_(True))
    if q:
        stmt = stmt.where(or_(Conductor.nombre.ilike(f"%{q}%"), Conductor.cedula.ilike(f"%{q}%"),
                              Conductor.placa.ilike(f"%{q}%")))
    return [_conductor_out(c, user) for c in db.scalars(stmt)]


@router.post("/conductores", status_code=status.HTTP_201_CREATED)
def crear_conductor(
    body: ConductorIn,
    user: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
) -> dict[str, object]:
    try:
        c, temporal = crear_usuario_conductor(db, cedula=body.cedula, nombre=body.nombre,
                                              telefono=body.telefono, placa=body.placa, clave=body.clave)
    except ConflictoDatos as exc:
        db.rollback()
        raise _conflict(exc) from exc
    c.activo = body.activo
    db.commit()
    cred = CredencialTemporal(usuario=c.cedula, nombre=c.nombre, clave_temporal=temporal) if temporal else None
    return {"conductor": _conductor_out(c, user), "credencial": cred}


@router.patch("/conductores/{conductor_id}", response_model=ConductorOut)
def editar_conductor(
    conductor_id: int,
    body: ConductorUpdate,
    user: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
) -> ConductorOut:
    c = db.get(Conductor, conductor_id)
    if c is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Conductor no encontrado")
    data = body.model_dump(exclude_unset=True)
    if "nombre" in data:
        c.nombre = data["nombre"].strip()
        if c.usuario:
            c.usuario.nombre = c.nombre
    if "telefono" in data:
        c.telefono = clean_phone(data["telefono"])
    if "placa" in data:
        c.placa = clean_code(data["placa"], 20)
    if "activo" in data:
        c.activo = data["activo"]
        if c.usuario:
            c.usuario.activo = data["activo"]
            c.usuario.token_version += 1
    db.commit()
    return _conductor_out(c, user)


@router.delete("/conductores/{conductor_id}")
def eliminar_conductor(
    conductor_id: int,
    _: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
) -> dict[str, object]:
    """Si tiene remesas se desactiva (se conserva el historial); si no, se elimina."""
    c = db.get(Conductor, conductor_id)
    if c is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Conductor no encontrado")
    tiene_historial = db.scalar(select(exists().where(Remesa.conductor_id == c.id)))
    usuario = c.usuario
    if tiene_historial:
        c.activo = False
        if usuario:
            usuario.activo = False
            usuario.token_version += 1
        db.commit()
        return {"eliminado": False, "desactivado": True}
    db.delete(c)
    if usuario:
        db.delete(usuario)
    db.commit()
    return {"eliminado": True, "desactivado": False}


@router.post("/conductores/{conductor_id}/clave", response_model=CredencialTemporal)
def resetear_clave_conductor(
    conductor_id: int,
    _: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
) -> CredencialTemporal:
    c = db.get(Conductor, conductor_id)
    if c is None or c.usuario is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Conductor sin usuario")
    temporal = generate_temp_password()
    c.usuario.password_hash = hash_password(temporal)
    c.usuario.debe_cambiar_clave = True
    c.usuario.token_version += 1
    db.commit()
    return CredencialTemporal(usuario=c.usuario.username, nombre=c.nombre, clave_temporal=temporal)


# --------------------------------------------------------------------- Camiones
@router.get("/camiones", response_model=list[CamionOut])
def listar_camiones(
    _: Usuario = Depends(require_roles(*STAFF_READ)), db: Session = Depends(get_db)
) -> list[Camion]:
    return list(db.scalars(select(Camion).order_by(Camion.placa)))


@router.post("/camiones", response_model=CamionOut, status_code=status.HTTP_201_CREATED)
def crear_camion(
    body: CamionIn, _: Usuario = Depends(require_roles(*STAFF_WRITE)), db: Session = Depends(get_db)
) -> Camion:
    placa = clean_code(body.placa, 20)
    if not placa:
        raise HTTPException(422, "Placa inválida")
    if db.scalar(select(Camion.id).where(Camion.placa == placa)):
        raise HTTPException(status.HTTP_409_CONFLICT, f"Ya existe el camión {placa}")
    cam = Camion(placa=placa, color=body.color, serial=clean_code(body.serial, 60), clase=body.clase,
                 activo=body.activo)
    db.add(cam)
    db.commit()
    return cam


@router.patch("/camiones/{camion_id}", response_model=CamionOut)
def editar_camion(
    camion_id: int,
    body: CamionUpdate,
    _: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
) -> Camion:
    cam = db.get(Camion, camion_id)
    if cam is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Camión no encontrado")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(cam, k, clean_code(v, 60) if k == "serial" else v)
    db.commit()
    return cam


@router.delete("/camiones/{camion_id}", status_code=status.HTTP_204_NO_CONTENT)
def eliminar_camion(
    camion_id: int, _: Usuario = Depends(require_roles(*STAFF_WRITE)), db: Session = Depends(get_db)
) -> None:
    cam = db.get(Camion, camion_id)
    if cam is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Camión no encontrado")
    db.delete(cam)  # las remesas guardan la placa como texto: el historial no se pierde
    db.commit()


# --------------------------------------------------------------------- Usuarios
def _user_out(u: Usuario) -> UsuarioOut:
    out = UsuarioOut.model_validate(u)
    out.conductor_id = u.conductor.id if u.conductor else None
    return out


@router.get("/usuarios", response_model=list[UsuarioOut])
def listar_usuarios(
    incluir_conductores: bool = False,
    _: Usuario = Depends(require_roles(Rol.SUPERVISOR)),
    db: Session = Depends(get_db),
) -> list[UsuarioOut]:
    stmt = select(Usuario).order_by(Usuario.rol, Usuario.nombre)
    if not incluir_conductores:
        stmt = stmt.where(Usuario.rol != Rol.CONDUCTOR.value)
    return [_user_out(u) for u in db.scalars(stmt)]


@router.post("/usuarios", status_code=status.HTTP_201_CREATED)
def crear_usuario_api(
    body: UsuarioIn, _: Usuario = Depends(require_roles(Rol.SUPERVISOR)), db: Session = Depends(get_db)
) -> dict[str, object]:
    try:
        u, temporal = crear_usuario(db, username=body.username, nombre=body.nombre, rol=Rol(body.rol),
                                    clave=body.clave, email=body.email)
    except ConflictoDatos as exc:
        db.rollback()
        raise _conflict(exc) from exc
    db.commit()
    cred = CredencialTemporal(usuario=u.username, nombre=u.nombre, clave_temporal=temporal) if temporal else None
    return {"usuario": _user_out(u), "credencial": cred}


@router.patch("/usuarios/{usuario_id}", response_model=UsuarioOut)
def editar_usuario(
    usuario_id: int,
    body: UsuarioUpdate,
    actor: Usuario = Depends(require_roles(Rol.SUPERVISOR)),
    db: Session = Depends(get_db),
) -> UsuarioOut:
    u = db.get(Usuario, usuario_id)
    if u is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Usuario no encontrado")
    data = body.model_dump(exclude_unset=True)
    if u.id == actor.id and (data.get("activo") is False or data.get("rol", Rol.SUPERVISOR.value) != "supervisor"):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "No puede quitarse a sí mismo el rol o desactivarse")
    if u.rol == Rol.CONDUCTOR.value and "rol" in data:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "El rol de un conductor no se cambia aquí")
    for k, v in data.items():
        setattr(u, k, v)
    if "activo" in data or "rol" in data:
        u.token_version += 1
    db.commit()
    return _user_out(u)


@router.delete("/usuarios/{usuario_id}")
def eliminar_usuario(
    usuario_id: int,
    actor: Usuario = Depends(require_roles(Rol.SUPERVISOR)),
    db: Session = Depends(get_db),
) -> dict[str, object]:
    u = db.get(Usuario, usuario_id)
    if u is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Usuario no encontrado")
    if u.id == actor.id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "No puede eliminarse a sí mismo")
    if u.conductor is not None:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Elimine al conductor desde la sección Conductores")
    db.delete(u)  # eventos/importaciones quedan con usuario NULL (historial intacto)
    db.commit()
    return {"eliminado": True}


@router.post("/usuarios/{usuario_id}/clave", response_model=CredencialTemporal)
def resetear_clave_usuario(
    usuario_id: int, _: Usuario = Depends(require_roles(Rol.SUPERVISOR)), db: Session = Depends(get_db)
) -> CredencialTemporal:
    u = db.get(Usuario, usuario_id)
    if u is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Usuario no encontrado")
    temporal = generate_temp_password()
    u.password_hash = hash_password(temporal)
    u.debe_cambiar_clave = True
    u.token_version += 1
    db.commit()
    return CredencialTemporal(usuario=u.username, nombre=u.nombre, clave_temporal=temporal)


# ------------------------------------------------------------------- Vendedores
@router.get("/vendedores", response_model=list[VendedorOut])
def listar_vendedores(
    _: Usuario = Depends(require_roles(*STAFF_READ)), db: Session = Depends(get_db)
) -> list[Vendedor]:
    return list(db.scalars(select(Vendedor).order_by(Vendedor.codigo)))


@router.post("/vendedores", response_model=VendedorOut, status_code=status.HTTP_201_CREATED)
def crear_vendedor(
    body: VendedorIn, _: Usuario = Depends(require_roles(*STAFF_WRITE)), db: Session = Depends(get_db)
) -> Vendedor:
    codigo = clean_code(body.codigo, 20)
    if not codigo:
        raise HTTPException(422, "Código inválido")
    if db.get(Vendedor, codigo):
        raise HTTPException(status.HTTP_409_CONFLICT, f"Ya existe el vendedor {codigo}")
    v = Vendedor(codigo=codigo, nombre=body.nombre, territorio=body.territorio, email=body.email,
                 activo=body.activo)
    db.add(v)
    db.commit()
    return v


@router.patch("/vendedores/{codigo}", response_model=VendedorOut)
def editar_vendedor(
    codigo: str,
    body: VendedorUpdate,
    _: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
) -> Vendedor:
    v = db.get(Vendedor, codigo.upper())
    if v is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Vendedor no encontrado")
    for k, val in body.model_dump(exclude_unset=True).items():
        setattr(v, k, val)
    db.commit()
    return v


@router.delete("/vendedores/{codigo}", status_code=status.HTTP_204_NO_CONTENT)
def eliminar_vendedor(
    codigo: str, _: Usuario = Depends(require_roles(*STAFF_WRITE)), db: Session = Depends(get_db)
) -> None:
    v = db.get(Vendedor, codigo.upper())
    if v is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Vendedor no encontrado")
    en_uso = db.scalar(select(func.count(Factura.id)).where(Factura.cod_vendedor == v.codigo))
    if en_uso:
        v.activo = False  # las facturas guardan el código; se desactiva para no perder la referencia
    else:
        db.delete(v)
    db.commit()


# -------------------------------------------------------------- Carga catálogos
@router.post("/catalogos/vendedores")
async def cargar_vendedores(
    archivo: UploadFile = File(...),
    _: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> dict[str, object]:
    data = await leer_excel(archivo, settings.max_excel_mb)
    try:
        r = await run_in_threadpool(importar_vendedores, db, io.BytesIO(data))
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return {"creados": r.creados, "actualizados": r.actualizados, "omitidos": r.omitidos}


@router.post("/catalogos/placas/filas")
async def cargar_placas_filas(
    request: Request,
    _: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> dict[str, object]:
    """Hoja PLACAS ya leída en el navegador (evita subir el libro completo)."""
    try:
        body = FilasExcelIn.model_validate(await leer_json(request, settings.max_excel_mb))
        r = await run_in_threadpool(importar_placas_filas, db, body.filas)
    except ValidationError as exc:
        raise HTTPException(422, "Formato de filas inválido") from exc
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return {"creados": r.creados, "actualizados": r.actualizados, "omitidos": r.omitidos,
            "credenciales": r.credenciales, "detalle": r.detalle[:50]}


@router.post("/catalogos/placas")
async def cargar_placas(
    archivo: UploadFile = File(...),
    hoja: str = Form("PLACAS"),
    _: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> dict[str, object]:
    data = await leer_excel(archivo, settings.max_excel_mb)
    try:
        r = await run_in_threadpool(importar_placas, db, io.BytesIO(data), hoja)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return {"creados": r.creados, "actualizados": r.actualizados, "omitidos": r.omitidos,
            "credenciales": r.credenciales, "detalle": r.detalle[:50]}
