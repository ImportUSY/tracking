"""Consulta y gestión de remesas y facturas (Transportista, Supervisor, Cobranzas solo lectura)."""

from __future__ import annotations

import uuid
from collections import defaultdict
from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import Exists, case, exists, func, or_, select
from sqlalchemy.orm import Session, aliased, selectinload

from tracking.enums import Estatus, OrigenEvento, Rol
from tracking.models import Conductor, EventoEstatus, Factura, Remesa, Usuario
from tracking.schemas import (
    CambioEstatusAdminIn,
    EventoOut,
    FacturaDetalleOut,
    FacturaOut,
    Pagina,
    ReasignarRemesaIn,
    RemesaDetalleOut,
    RemesaOut,
)
from tracking.security import STAFF_READ, STAFF_WRITE, can_see_personal_data, get_db, require_roles
from tracking.services.status import EventoRechazado, aplicar_evento
from tracking.services.timeutil import local_day_bounds
from tracking.services.tracking_codes import normalize_query

router = APIRouter(prefix="/api", tags=["remesas"])

FINALES = [Estatus.ENTREGADA.value, Estatus.DEVOLUCION.value]
_F2 = aliased(Factura)


def _remesa_abierta() -> Exists:
    """EXISTS: la remesa tiene al menos una factura sin estatus final (alias explícito para correlación)."""
    return exists(
        select(_F2.id).where(_F2.remesa_id == Remesa.id, _F2.estatus.not_in(FINALES)).correlate(Remesa)
    )


def _conteos(db: Session, remesa_ids: list[int]) -> dict[int, dict[str, int]]:
    out: dict[int, dict[str, int]] = defaultdict(dict)
    if not remesa_ids:
        return out
    stmt = (
        select(Factura.remesa_id, Factura.estatus, func.count(Factura.id))
        .where(Factura.remesa_id.in_(remesa_ids))
        .group_by(Factura.remesa_id, Factura.estatus)
    )
    for rid, est, n in db.execute(stmt):
        out[rid][est] = int(n)
    return out


def _remesa_out(r: Remesa, conteo: dict[str, int], user: Usuario, cls: type[RemesaOut] = RemesaOut) -> RemesaOut:
    out = cls.model_validate(r)
    total = sum(conteo.values())
    finales = sum(v for k, v in conteo.items() if k in FINALES)
    out.total_facturas = total
    out.por_estatus = conteo
    out.progreso = round(finales / total, 3) if total else 0.0
    if can_see_personal_data(user):
        out.chofer_cedula = r.chofer_cedula
        out.chofer_telefono = r.chofer_telefono
    else:
        out.chofer_cedula = None
        out.chofer_telefono = None
    return out


def _factura_out(f: Factura, cls: type[FacturaOut] = FacturaOut) -> FacturaOut:
    out = cls.model_validate(f)
    out.remesa_numero = f.remesa.numero if f.remesa else None
    out.conductor_nombre = f.remesa.chofer_nombre if f.remesa else None
    return out


@router.get("/remesas", response_model=Pagina)
def listar_remesas(
    q: str | None = None,
    estado: str = Query("todas", pattern="^(activas|completas|todas)$"),
    desde: date | None = None,
    hasta: date | None = None,
    conductor_id: int | None = None,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    user: Usuario = Depends(require_roles(*STAFF_READ)),
    db: Session = Depends(get_db),
) -> Pagina:
    stmt = select(Remesa)
    if q:
        term = f"%{q.strip()}%"
        stmt = stmt.where(or_(Remesa.numero.ilike(term), Remesa.chofer_nombre.ilike(term),
                              Remesa.destino.ilike(term), Remesa.placa.ilike(term)))
    if conductor_id:
        stmt = stmt.where(Remesa.conductor_id == conductor_id)
    ini, fin = local_day_bounds(desde, hasta)
    if ini:
        stmt = stmt.where(Remesa.created_at >= ini)
    if fin:
        stmt = stmt.where(Remesa.created_at < fin)
    abiertas = _remesa_abierta()
    if estado == "activas":
        stmt = stmt.where(abiertas)
    elif estado == "completas":
        stmt = stmt.where(~abiertas)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    remesas = list(db.scalars(stmt.order_by(Remesa.id.desc()).limit(limit).offset(offset)))
    conteos = _conteos(db, [r.id for r in remesas])
    return Pagina(total=total, items=[_remesa_out(r, conteos.get(r.id, {}), user) for r in remesas])


@router.get("/remesas/{remesa_id}", response_model=RemesaDetalleOut)
def detalle_remesa(
    remesa_id: int,
    user: Usuario = Depends(require_roles(*STAFF_READ)),
    db: Session = Depends(get_db),
) -> RemesaOut:
    r = db.scalar(select(Remesa).options(selectinload(Remesa.facturas)).where(Remesa.id == remesa_id))
    if r is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Remesa no encontrada")
    out = _remesa_out(r, _conteos(db, [r.id]).get(r.id, {}), user, RemesaDetalleOut)
    assert isinstance(out, RemesaDetalleOut)
    out.facturas = [_factura_out(f) for f in r.facturas]
    return out


@router.post("/remesas/{remesa_id}/reasignar", response_model=RemesaOut)
def reasignar_remesa(
    remesa_id: int,
    body: ReasignarRemesaIn,
    user: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
) -> RemesaOut:
    r = db.get(Remesa, remesa_id)
    c = db.get(Conductor, body.conductor_id)
    if r is None or c is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Remesa o conductor no encontrado")
    r.conductor_id = c.id
    r.chofer_cedula, r.chofer_nombre, r.chofer_telefono = c.cedula, c.nombre, c.telefono
    r.placa = c.placa or r.placa
    for f in r.facturas:
        f.conductor_id = c.id
    db.commit()
    return _remesa_out(r, _conteos(db, [r.id]).get(r.id, {}), user)


@router.delete("/remesas/{remesa_id}", status_code=status.HTTP_204_NO_CONTENT)
def eliminar_remesa(
    remesa_id: int,
    _: Usuario = Depends(require_roles(Rol.SUPERVISOR)),
    db: Session = Depends(get_db),
) -> None:
    """Solo Supervisor: borra una remesa cargada por error (con sus facturas e historial)."""
    r = db.get(Remesa, remesa_id)
    if r is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Remesa no encontrada")
    db.delete(r)
    db.commit()


@router.get("/facturas", response_model=Pagina)
def buscar_facturas(
    q: str | None = None,
    estatus: Estatus | None = None,
    conductor_id: int | None = None,
    cod_vendedor: str | None = None,
    desde: date | None = None,
    hasta: date | None = None,
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    _: Usuario = Depends(require_roles(*STAFF_READ)),
    db: Session = Depends(get_db),
) -> Pagina:
    stmt = select(Factura).options(selectinload(Factura.remesa))
    if q:
        term = normalize_query(q)
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(Factura.numero == term, Factura.pedido == term, Factura.tracking == term,
                              Factura.numero.ilike(like), Factura.cliente.ilike(like)))
    if estatus:
        stmt = stmt.where(Factura.estatus == estatus.value)
    if conductor_id:
        stmt = stmt.where(Factura.conductor_id == conductor_id)
    if cod_vendedor:
        stmt = stmt.where(Factura.cod_vendedor == cod_vendedor.strip().upper())
    ini, fin = local_day_bounds(desde, hasta)
    if ini:
        stmt = stmt.where(Factura.estatus_at >= ini)
    if fin:
        stmt = stmt.where(Factura.estatus_at < fin)
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(Factura.estatus_at.desc()).limit(limit).offset(offset))
    return Pagina(total=total, items=[_factura_out(f) for f in rows])


@router.get("/facturas/{factura_id}", response_model=FacturaDetalleOut)
def detalle_factura(
    factura_id: int,
    _: Usuario = Depends(require_roles(*STAFF_READ)),
    db: Session = Depends(get_db),
) -> FacturaOut:
    f = db.scalar(
        select(Factura)
        .options(selectinload(Factura.remesa), selectinload(Factura.eventos).selectinload(EventoEstatus.usuario))
        .where(Factura.id == factura_id)
    )
    if f is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Factura no encontrada")
    out = _factura_out(f, FacturaDetalleOut)
    assert isinstance(out, FacturaDetalleOut)
    eventos = []
    for e in sorted(f.eventos, key=lambda e: (e.ocurrido_at, e.recibido_at)):
        eo = EventoOut.model_validate(e)
        eo.usuario_nombre = e.usuario.nombre if e.usuario else None
        eventos.append(eo)
    out.eventos = eventos
    return out


@router.post("/facturas/{factura_id}/estatus", response_model=FacturaOut)
def cambiar_estatus_admin(
    factura_id: int,
    body: CambioEstatusAdminIn,
    user: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
) -> FacturaOut:
    """Corrección manual de estatus (queda en el historial como origen 'admin')."""
    f = db.scalar(select(Factura).where(Factura.id == factura_id).with_for_update())
    if f is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Factura no encontrada")
    try:
        aplicar_evento(db, evento_id=str(uuid.uuid4()), factura=f, nuevo=body.estatus, usuario=user,
                       origen=OrigenEvento.ADMIN, motivo=body.motivo)
    except EventoRechazado as exc:
        db.rollback()
        raise HTTPException(status.HTTP_409_CONFLICT, exc.mensaje) from exc
    db.commit()
    db.refresh(f)
    return _factura_out(f)


@router.get("/dashboard")
def dashboard(
    _: Usuario = Depends(require_roles(*STAFF_READ)),
    db: Session = Depends(get_db),
) -> dict[str, object]:
    filas = db.execute(select(Factura.estatus, func.count(Factura.id)).group_by(Factura.estatus)).all()
    por_estatus: dict[str, int] = {str(est): int(n) for est, n in filas}
    abiertas = _remesa_abierta()
    remesas_activas = db.scalar(select(func.count(Remesa.id)).where(abiertas)) or 0
    por_chofer = db.execute(
        select(
            Remesa.chofer_nombre,
            func.count(Factura.id),
            func.sum(case((Factura.estatus.in_(FINALES), 1), else_=0)),
        )
        .join(Factura, Factura.remesa_id == Remesa.id)
        .where(abiertas)
        .group_by(Remesa.chofer_nombre)
        .order_by(Remesa.chofer_nombre)
    ).all()
    return {
        "por_estatus": {Estatus(k).label: int(v) for k, v in por_estatus.items()},
        "remesas_activas": int(remesas_activas),
        "choferes_en_ruta": [
            {"chofer": n or "-", "facturas": int(t), "cerradas": int(c or 0)} for n, t, c in por_chofer
        ],
    }

