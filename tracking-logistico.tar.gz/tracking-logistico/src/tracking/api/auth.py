"""Inicio de sesión, perfil propio y cambio de clave."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from tracking.config import Settings, get_settings
from tracking.enums import Rol
from tracking.models import Usuario
from tracking.schemas import CambioClaveIn, LoginIn, PerfilConductorIn, TokenOut, UsuarioOut
from tracking.security import (
    client_ip,
    create_access_token,
    get_current_user,
    get_db,
    hash_password,
    needs_rehash,
    validate_password_strength,
    verify_password,
)
from tracking.services.normalize import clean_cedula, clean_code, clean_phone
from tracking.services.timeutil import now_utc

router = APIRouter(prefix="/api", tags=["auth"])
log = logging.getLogger(__name__)

# Hash ficticio para igualar tiempos cuando el usuario no existe (evita enumeración por tiempo).
_DUMMY_HASH = hash_password("dummy-password-for-timing")


def usuario_out(user: Usuario) -> UsuarioOut:
    out = UsuarioOut.model_validate(user)
    out.conductor_id = user.conductor.id if user.conductor else None
    return out


@router.post("/auth/login", response_model=TokenOut)
def login(
    body: LoginIn,
    request: Request,
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> TokenOut:
    ip = client_ip(request, settings)
    limiter = request.app.state.login_limiter
    # Conductores entran con la cédula: tolerar "V-12.345.678"
    username = body.username
    if not db.scalar(select(Usuario.id).where(func.lower(Usuario.username) == username.lower())):
        ced = clean_cedula(username)
        if ced:
            username = ced
    key = f"{username.lower()}|{ip}"
    if not limiter.hit(key):
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, "Demasiados intentos. Espere unos minutos.")

    user = db.scalar(select(Usuario).where(func.lower(Usuario.username) == username.lower()))
    valido = verify_password(body.password, user.password_hash if user else _DUMMY_HASH)
    if user is None or not valido or not user.activo:
        log.warning("login_fallido", extra={"username": username, "ip": ip})
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Usuario o clave incorrectos")

    limiter.reset(key)
    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(body.password)
    user.ultimo_acceso_at = now_utc()
    db.commit()
    token, exp = create_access_token(user, settings)
    log.info("login_ok", extra={"usuario_id": user.id, "rol": user.rol})
    return TokenOut(access_token=token, expira=exp, usuario=usuario_out(user))


@router.get("/me", response_model=UsuarioOut)
def me(user: Usuario = Depends(get_current_user)) -> UsuarioOut:
    return usuario_out(user)


@router.post("/me/clave", response_model=TokenOut)
def cambiar_clave(
    body: CambioClaveIn,
    user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> TokenOut:
    if not verify_password(body.clave_actual, user.password_hash):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "La clave actual no es correcta")
    validate_password_strength(body.clave_nueva)
    if body.clave_nueva == body.clave_actual:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "La clave nueva debe ser distinta")
    user.password_hash = hash_password(body.clave_nueva)
    user.debe_cambiar_clave = False
    user.token_version += 1  # invalida sesiones anteriores
    db.commit()
    token, exp = create_access_token(user, settings)
    return TokenOut(access_token=token, expira=exp, usuario=usuario_out(user))


@router.get("/me/perfil")
def ver_perfil(user: Usuario = Depends(get_current_user)) -> dict[str, object]:
    c = user.conductor
    return {
        "usuario": usuario_out(user).model_dump(),
        "conductor": None if c is None else {
            "id": c.id, "cedula": c.cedula, "nombre": c.nombre, "telefono": c.telefono, "placa": c.placa,
        },
    }


@router.patch("/me/perfil")
def editar_perfil(
    body: PerfilConductorIn,
    user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict[str, object]:
    """El conductor corrige sus propios datos (nombre, placa, teléfono)."""
    if user.rol != Rol.CONDUCTOR.value or user.conductor is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Solo disponible para conductores")
    c = user.conductor
    if body.nombre is not None:
        c.nombre = body.nombre.strip()
        user.nombre = c.nombre
    if body.placa is not None:
        c.placa = clean_code(body.placa, 20)
    if body.telefono is not None:
        c.telefono = clean_phone(body.telefono)
    db.commit()
    return ver_perfil(user)
