"""Excel para Cobranzas, correos a vendedores/Cobranzas y métricas."""

from __future__ import annotations

import logging
from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool

from tracking.config import Settings, get_settings
from tracking.models import Usuario, Vendedor
from tracking.schemas import NotificarCobranzasIn, NotificarVendedoresIn
from tracking.security import STAFF_READ, STAFF_WRITE, get_db, require_roles
from tracking.services.cobranzas_excel import generar_excel_cobranzas
from tracking.services.notifications import (
    CorreoNoConfigurado,
    EmailSender,
    correo_cobranzas,
    correo_vendedor,
)
from tracking.services.reportes import facturas_por_vendedor, metricas, seleccionar_para_cobranzas
from tracking.services.timeutil import today_local

router = APIRouter(prefix="/api/reportes", tags=["reportes"])
log = logging.getLogger(__name__)

XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def _nombre_archivo(desde: date | None, hasta: date | None) -> str:
    d = desde or today_local()
    h = hasta or d
    return f"Entregas_Cobranzas_{d:%Y%m%d}" + (f"_{h:%Y%m%d}" if h != d else "") + ".xlsx"


@router.get("/cobranzas.xlsx")
def descargar_excel_cobranzas(
    desde: date | None = None,
    hasta: date | None = None,
    remesa_ids: list[int] | None = Query(default=None),
    solo_finales: bool = False,
    _: Usuario = Depends(require_roles(*STAFF_READ)),
    db: Session = Depends(get_db),
) -> Response:
    seleccion = seleccionar_para_cobranzas(db, remesa_ids, desde, hasta, solo_finales)
    if not seleccion:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No hay facturas para el filtro indicado")
    data = generar_excel_cobranzas(seleccion)
    nombre = _nombre_archivo(desde, hasta)
    return Response(data, media_type=XLSX, headers={"Content-Disposition": f'attachment; filename="{nombre}"'})


@router.post("/notificar/vendedores")
async def notificar_vendedores(
    body: NotificarVendedoresIn,
    request: Request,
    _: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> dict[str, object]:
    grupos = facturas_por_vendedor(db, body.modo, body.desde, body.hasta, body.remesa_ids)
    vendedores = {v.codigo: v for v in db.scalars(select(Vendedor).where(Vendedor.codigo.in_(list(grupos))))}
    sender = EmailSender(settings)
    if not body.simular:
        try:
            sender.verificar()
        except CorreoNoConfigurado as exc:
            raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
    enviados, sin_correo, errores, vista = [], [], [], []
    for codigo, facturas in grupos.items():
        correo = correo_vendedor(vendedores.get(codigo), codigo, facturas, body.modo, request.app.state.ai)
        if correo is None:
            sin_correo.append(codigo)
            continue
        if body.simular:
            vista.append({"codigo": codigo, "para": correo.para, "asunto": correo.asunto, "texto": correo.texto})
            continue
        try:
            await run_in_threadpool(sender.enviar, correo)
            enviados.append(codigo)
        except Exception as exc:
            log.exception("correo_vendedor_fallo", extra={"codigo": codigo})
            errores.append({"codigo": codigo, "error": str(exc)[:200]})
    return {"enviados": enviados, "sin_correo": sin_correo, "errores": errores, "vista_previa": vista,
            "vendedores": len(grupos)}


@router.post("/notificar/cobranzas")
async def notificar_cobranzas(
    body: NotificarCobranzasIn,
    _: Usuario = Depends(require_roles(*STAFF_WRITE)),
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> dict[str, object]:
    seleccion = seleccionar_para_cobranzas(db, body.remesa_ids, body.desde, body.hasta, body.solo_finales)
    if not seleccion:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No hay facturas para el filtro indicado")
    n_fact = sum(len(f) for _, f in seleccion)
    if body.simular:
        return {"enviado": False, "remesas": len(seleccion), "facturas": n_fact, "para": settings.cobranzas_email_list}
    if not settings.cobranzas_email_list:
        raise HTTPException(status.HTTP_409_CONFLICT, "Configure COBRANZAS_EMAILS")
    sender = EmailSender(settings)
    try:
        sender.verificar()
    except CorreoNoConfigurado as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
    nombre = _nombre_archivo(body.desde, body.hasta)
    excel = generar_excel_cobranzas(seleccion)
    correo = correo_cobranzas(settings.cobranzas_email_list, excel, nombre, len(seleccion), n_fact)
    try:
        await run_in_threadpool(sender.enviar, correo)
    except Exception as exc:
        log.exception("correo_cobranzas_fallo")
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, f"No se pudo enviar el correo: {exc}") from exc
    return {"enviado": True, "remesas": len(seleccion), "facturas": n_fact, "para": settings.cobranzas_email_list}


@router.get("/metricas")
def ver_metricas(
    desde: date | None = None,
    hasta: date | None = None,
    _: Usuario = Depends(require_roles(*STAFF_READ)),
    db: Session = Depends(get_db),
) -> dict[str, object]:
    return metricas(db, desde, hasta)
