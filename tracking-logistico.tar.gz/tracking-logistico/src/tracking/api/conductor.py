"""App del conductor: sus facturas, cambios de estatus en lote (online/offline) y fotos."""

from __future__ import annotations

import hashlib
import logging
from datetime import timedelta

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from fastapi.responses import FileResponse, Response
from sqlalchemy import exists, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from tracking.config import Settings, get_settings
from tracking.enums import Estatus, OrigenEvento, Rol
from tracking.models import EventoEstatus, Factura, Foto, Remesa, Usuario
from tracking.schemas import (
    EventoIn,
    EventoResultado,
    FacturaConductorOut,
    LoteEventosIn,
    LoteEventosOut,
)
from tracking.security import STAFF_READ, get_current_user, get_db, require_roles
from tracking.services.photos import FotoInvalida, detectar_tipo, validar_id
from tracking.services.status import EventoRechazado, aplicar_evento, puede_operar_factura
from tracking.services.timeutil import now_utc

router = APIRouter(prefix="/api", tags=["conductor"])
log = logging.getLogger(__name__)


def _conductor_id(user: Usuario) -> int:
    if user.conductor is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Su usuario no está asociado a un conductor")
    return user.conductor.id


@router.get("/conductor/facturas")
def mis_facturas(
    dias_finales: int = 3,
    user: Usuario = Depends(require_roles(Rol.CONDUCTOR)),
    db: Session = Depends(get_db),
) -> dict[str, object]:
    """Facturas abiertas del conductor + las cerradas en los últimos `dias_finales` días."""
    cid = _conductor_id(user)
    limite = now_utc() - timedelta(days=max(0, min(dias_finales, 30)))
    tiene_foto = exists().where(Foto.factura_id == Factura.id)
    stmt = (
        select(Factura, Remesa.numero, Remesa.destino, tiene_foto.label("tiene_foto"))
        .join(Remesa, Remesa.id == Factura.remesa_id)
        .where(Factura.conductor_id == cid)
        .where(
            or_(
                Factura.estatus.not_in([Estatus.ENTREGADA.value, Estatus.DEVOLUCION.value]),
                Factura.estatus_at >= limite,
            )
        )
        .order_by(Remesa.numero, Factura.id)
    )
    items = []
    for f, rem_num, destino, foto in db.execute(stmt):
        items.append(
            FacturaConductorOut(
                id=f.id, numero=f.numero, pedido=f.pedido, cliente=f.cliente, empresa=f.empresa,
                bultos=f.bultos, comentario=f.comentario, estatus=f.estatus, estatus_at=f.estatus_at,
                tracking=f.tracking, remesa_id=f.remesa_id, remesa_numero=rem_num, destino=destino,
                tiene_foto=bool(foto),
            ).model_dump(mode="json")
        )
    return {"servidor_at": now_utc().isoformat(), "facturas": items}


def _procesar_evento(db: Session, user: Usuario, ev: EventoIn) -> EventoResultado:
    factura = db.scalar(select(Factura).where(Factura.id == ev.factura_id).with_for_update())
    if factura is None:
        return EventoResultado(id=ev.id, ok=False, factura_id=ev.factura_id,
                               error="Factura no encontrada", codigo_error="no_encontrada")
    try:
        r = aplicar_evento(
            db,
            evento_id=ev.id,
            factura=factura,
            nuevo=ev.estatus,
            usuario=user,
            origen=OrigenEvento.OFFLINE if ev.offline else OrigenEvento.ONLINE,
            ocurrido_at=ev.ocurrido_at,
            motivo=ev.motivo,
            foto_id=ev.foto_id.lower() if ev.foto_id else None,
        )
        db.commit()
    except EventoRechazado as exc:
        db.rollback()
        db.refresh(factura)
        return EventoResultado(id=ev.id, ok=False, factura_id=factura.id, estatus_actual=factura.estatus,
                               estatus_at=factura.estatus_at, tracking=factura.tracking,
                               error=exc.mensaje, codigo_error=exc.codigo)
    except IntegrityError:
        # Mismo evento enviado dos veces en paralelo: el otro ya lo guardó.
        db.rollback()
        previo = db.get(EventoEstatus, ev.id)
        factura = db.get(Factura, ev.factura_id)
        if previo is None or factura is None:
            raise
        return EventoResultado(id=ev.id, ok=True, aplicado=previo.aplicado, duplicado=True,
                               factura_id=factura.id, estatus_actual=factura.estatus,
                               estatus_at=factura.estatus_at, tracking=factura.tracking)
    return EventoResultado(id=ev.id, ok=True, aplicado=r.aplicado, duplicado=r.duplicado,
                           factura_id=factura.id, estatus_actual=factura.estatus,
                           estatus_at=factura.estatus_at, tracking=factura.tracking)


@router.post("/conductor/eventos", response_model=LoteEventosOut)
def registrar_eventos(
    body: LoteEventosIn,
    user: Usuario = Depends(require_roles(Rol.CONDUCTOR)),
    db: Session = Depends(get_db),
) -> LoteEventosOut:
    """Aplica cambios de estatus en lote. Cada evento es independiente e idempotente por su `id`."""
    _conductor_id(user)
    resultados = [_procesar_evento(db, user, ev) for ev in body.eventos]
    return LoteEventosOut(resultados=resultados, servidor_at=now_utc())


@router.put("/fotos/{foto_id}", status_code=status.HTTP_201_CREATED)
async def subir_foto(
    foto_id: str,
    request: Request,
    factura_id: int = Form(...),
    archivo: UploadFile = File(...),
    user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> dict[str, object]:
    """Sube la foto de una factura. Idempotente: reenviar el mismo id no duplica."""
    try:
        foto_id = validar_id(foto_id)
    except FotoInvalida as exc:
        raise HTTPException(422, str(exc)) from exc
    factura = db.get(Factura, factura_id)
    if factura is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Factura no encontrada")
    if not puede_operar_factura(user, factura):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Esta factura no está asignada a usted")
    previa = db.get(Foto, foto_id)
    if previa is not None:
        if previa.factura_id != factura.id:
            raise HTTPException(status.HTTP_409_CONFLICT, "El id de foto ya pertenece a otra factura")
        return {"id": previa.id, "duplicado": True}

    limite = settings.max_photo_mb * 1024 * 1024
    data = await archivo.read(limite + 1)
    if len(data) > limite:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, f"La foto supera {settings.max_photo_mb} MB")
    datos: bytes | None = None
    try:
        if settings.storage_backend == "db":
            ctype, sha, ruta, datos = detectar_tipo(data), hashlib.sha256(data).hexdigest(), "db", data
        else:
            ruta, ctype, sha = request.app.state.photos.guardar(foto_id, factura.id, data)
    except FotoInvalida as exc:
        raise HTTPException(422, str(exc)) from exc
    db.add(Foto(id=foto_id, factura_id=factura.id, ruta=ruta, content_type=ctype, bytes=len(data),
                sha256=sha, subido_por_id=user.id, datos=datos))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        return {"id": foto_id, "duplicado": True}
    log.info("foto_subida", extra={"foto_id": foto_id, "factura_id": factura.id, "bytes": len(data)})
    return {"id": foto_id, "duplicado": False}


@router.get("/fotos/{foto_id}")
def ver_foto(
    foto_id: str,
    request: Request,
    user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> Response:
    foto = db.get(Foto, foto_id.lower())
    if foto is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Foto no encontrada")
    factura = db.get(Factura, foto.factura_id)
    permitido = user.rol in {r.value for r in STAFF_READ} or (
        factura is not None and puede_operar_factura(user, factura)
    )
    if not permitido:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "No tiene permiso para ver esta foto")
    cache = {"Cache-Control": "private, max-age=86400"}
    if foto.ruta == "db":
        if foto.datos is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "El archivo de la foto no está disponible")
        return Response(foto.datos, media_type=foto.content_type, headers=cache)
    path = request.app.state.photos.ruta_absoluta(foto.ruta)
    if not path.exists():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "El archivo de la foto no está disponible")
    return FileResponse(path, media_type=foto.content_type, headers=cache)
