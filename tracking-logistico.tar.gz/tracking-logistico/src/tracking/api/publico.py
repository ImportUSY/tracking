"""Consulta pública de tracking (vendedores, sin usuario ni clave).

Solo expone estatus, fechas y datos generales. Nunca montos, cédulas, teléfonos ni fotos.
"""

from __future__ import annotations

import hashlib

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import or_, select
from sqlalchemy.orm import Session, selectinload

from tracking.config import Settings, get_settings
from tracking.enums import Estatus
from tracking.models import ConsultaPublica, Factura
from tracking.schemas import ConsultaPublicaOut, HitoPublico, TrackingPublicoOut
from tracking.security import client_ip, get_db
from tracking.services.tracking_codes import normalize_query

router = APIRouter(prefix="/api/publico", tags=["publico"])

NO_ENCONTRADO = "No encontramos esa factura, pedido o tracking."


def _variantes(term: str) -> list[str]:
    """Tolera que el vendedor escriba sin prefijo: 'U00099434' -> 'FAC-U00099434'."""
    out = {term}
    if not term.startswith(("FAC-", "PED-", "TR-")):
        out.update({f"FAC-{term}", f"PED-{term}", f"TR-{term}"})
    return sorted(out)


@router.get("/tracking", response_model=ConsultaPublicaOut)
def consultar(
    request: Request,
    q: str = Query(..., min_length=3, max_length=40),
    db: Session = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> ConsultaPublicaOut:
    ip = client_ip(request, settings)
    if not request.app.state.public_limiter.hit(ip):
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, "Demasiadas consultas. Intente en un minuto.")
    term = normalize_query(q)
    variantes = _variantes(term)
    stmt = (
        select(Factura)
        .options(selectinload(Factura.remesa), selectinload(Factura.eventos))
        .where(or_(Factura.numero.in_(variantes), Factura.pedido.in_(variantes), Factura.tracking.in_(variantes)))
        .order_by(Factura.id.desc())
        .limit(10)
    )
    facturas = list(db.scalars(stmt))
    ip_hash = hashlib.sha256(f"{settings.secret_key[:8]}|{ip}".encode()).hexdigest()
    db.add(ConsultaPublica(termino=term[:60], encontrado=bool(facturas), ip_hash=ip_hash))
    db.commit()
    if not facturas:
        return ConsultaPublicaOut(encontrado=False, mensaje=NO_ENCONTRADO)
    resultados = []
    for f in facturas:
        historial = [
            HitoPublico(estatus=Estatus(e.estatus).label, fecha=e.ocurrido_at)
            for e in sorted(f.eventos, key=lambda e: e.ocurrido_at)
            if e.aplicado
        ]
        resultados.append(
            TrackingPublicoOut(
                numero=f.numero,
                pedido=f.pedido,
                tracking=f.tracking,
                empresa=f.empresa,
                cliente=f.cliente,
                destino=f.remesa.destino if f.remesa else None,
                estatus=Estatus(f.estatus).label,
                estatus_at=f.estatus_at,
                historial=historial,
            )
        )
    return ConsultaPublicaOut(encontrado=True, resultados=resultados)
