"""Tracking Logístico: seguimiento de facturas desde Transporte hasta la entrega."""

__version__ = "1.2.0"
