"""Tracking Logístico: seguimiento de facturas desde Transporte hasta la entrega."""

__version__ = "1.1.0"
