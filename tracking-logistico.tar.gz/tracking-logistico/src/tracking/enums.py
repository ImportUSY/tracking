"""Enumeraciones del dominio."""

from __future__ import annotations

from enum import Enum


class Rol(str, Enum):
    SUPERVISOR = "supervisor"
    TRANSPORTISTA = "transportista"
    CONDUCTOR = "conductor"
    COBRANZAS = "cobranzas"


class Estatus(str, Enum):
    RECIBIDA = "recibida"
    CARGADO = "cargado"
    EN_TRANSITO = "en_transito"
    ENTREGADA = "entregada"
    DEVOLUCION = "devolucion"

    @property
    def label(self) -> str:
        return ESTATUS_LABELS[self]

    @property
    def orden(self) -> int:
        return ESTATUS_ORDEN[self]

    @property
    def es_final(self) -> bool:
        return self in (Estatus.ENTREGADA, Estatus.DEVOLUCION)


ESTATUS_LABELS: dict[Estatus, str] = {
    Estatus.RECIBIDA: "Recibida",
    Estatus.CARGADO: "Cargado",
    Estatus.EN_TRANSITO: "En Tránsito",
    Estatus.ENTREGADA: "Entregada",
    Estatus.DEVOLUCION: "Devolución",
}

ESTATUS_ORDEN: dict[Estatus, int] = {
    Estatus.RECIBIDA: 0,
    Estatus.CARGADO: 1,
    Estatus.EN_TRANSITO: 2,
    Estatus.ENTREGADA: 3,
    Estatus.DEVOLUCION: 3,
}


class EstadoImportacion(str, Enum):
    PREVIEW = "preview"
    CONFIRMADA = "confirmada"
    DESCARTADA = "descartada"


class OrigenEvento(str, Enum):
    IMPORTACION = "importacion"
    ONLINE = "online"
    OFFLINE = "offline"
    ADMIN = "admin"
