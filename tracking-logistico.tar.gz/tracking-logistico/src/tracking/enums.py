"""Enumeraciones del dominio."""

from __future__ import annotations

from enum import Enum


class Rol(str, Enum):
    SUPERVISOR = "supervisor"
    TRANSPORTISTA = "transportista"
    CONDUCTOR = "conductor"
    COBRANZAS = "cobranzas"


class Estatus(str, Enum):
    RECIBIDA = "recibida"
    CARGADO = "cargado"
    EN_TRANSITO = "en_transito"
    ENTREGADA = "entregada"
    DEVOLUCION = "devolucion"

    @property
    def label(self) -> str:
        return ESTATUS_LABELS[self]

    @property
    def orden(self) -> int:
        return ESTATUS_ORDEN[self]

    @property
    def es_final(self) -> bool:
        return self in (Estatus.ENTREGADA, Estatus.DEVOLUCION)


ESTATUS_LABELS: dict[Estatus, str] = {
    Estatus.RECIBIDA: "Recibida",
    Estatus.CARGADO: "Cargado",
    Estatus.EN_TRANSITO: "En Tránsito",
    Estatus.ENTREGADA: "Entregada",
    Estatus.DEVOLUCION: "Devolución",
}

ESTATUS_ORDEN: dict[Estatus, int] = {
    Estatus.RECIBIDA: 0,
    Estatus.CARGADO: 1,
    Estatus.EN_TRANSITO: 2,
    Estatus.ENTREGADA: 3,
    Estatus.DEVOLUCION: 3,
}


class TipoEventoOperativo(str, Enum):
    """Eventos del ciclo de transporte que el conductor puede registrar (y nada más)."""

    CARGA = "carga"
    SALIDA = "salida"
    ENTREGA = "entrega"
    DEVOLUCION = "devolucion"

    @property
    def estatus(self) -> Estatus:
        return EVENTO_A_ESTATUS[self]


EVENTO_A_ESTATUS: dict[TipoEventoOperativo, Estatus] = {
    TipoEventoOperativo.CARGA: Estatus.CARGADO,
    TipoEventoOperativo.SALIDA: Estatus.EN_TRANSITO,
    TipoEventoOperativo.ENTREGA: Estatus.ENTREGADA,
    TipoEventoOperativo.DEVOLUCION: Estatus.DEVOLUCION,
}
# Únicos valores de estatus que un CONDUCTOR puede asignar
ESTATUS_OPERATIVOS: frozenset[Estatus] = frozenset(EVENTO_A_ESTATUS.values())


class AccionAuditoria(str, Enum):
    USUARIO_CREADO = "usuario_creado"
    CONDUCTOR_CREADO = "conductor_creado"
    USUARIO_EDITADO = "usuario_editado"
    USUARIO_ELIMINADO = "usuario_eliminado"
    CLAVE_CAMBIADA = "clave_cambiada"  # el propio usuario
    CLAVE_ESTABLECIDA = "clave_establecida"  # un administrador fijó una clave concreta
    CLAVE_RESTABLECIDA = "clave_restablecida"  # un administrador generó una clave temporal
    CREDENCIAL_CONSULTADA = "credencial_consultada"


class EstadoImportacion(str, Enum):
    PREVIEW = "preview"
    CONFIRMADA = "confirmada"
    DESCARTADA = "descartada"


class OrigenEvento(str, Enum):
    IMPORTACION = "importacion"
    ONLINE = "online"
    OFFLINE = "offline"
    ADMIN = "admin"
