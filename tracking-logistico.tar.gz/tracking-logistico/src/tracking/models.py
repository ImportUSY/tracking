"""Modelo de datos (SQLAlchemy 2.0, tipado)."""

from __future__ import annotations

import builtins
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Any, Optional

from sqlalchemy import (
    JSON,
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    LargeBinary,
    Numeric,
    String,
    Text,
    TypeDecorator,
    UniqueConstraint,
)
from sqlalchemy.engine import Dialect
from sqlalchemy.orm import Mapped, mapped_column, relationship

from tracking.db import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class UTCDateTime(TypeDecorator[datetime]):
    """Guarda siempre en UTC y devuelve datetimes con zona (SQLite no conserva tz)."""

    impl = DateTime(timezone=True)
    cache_ok = True

    def process_bind_param(self, value: datetime | None, dialect: Dialect) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    def process_result_value(self, value: datetime | None, dialect: Dialect) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)


MONEY = Numeric(16, 4)


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), default=utcnow, onupdate=utcnow, nullable=False
    )


class Usuario(TimestampMixin, Base):
    __tablename__ = "usuarios"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    nombre: Mapped[str] = mapped_column(String(160))
    rol: Mapped[str] = mapped_column(String(20), index=True)
    email: Mapped[str | None] = mapped_column(String(200))
    password_hash: Mapped[str] = mapped_column(String(255))
    activo: Mapped[bool] = mapped_column(Boolean, default=True)
    debe_cambiar_clave: Mapped[bool] = mapped_column(Boolean, default=False)
    token_version: Mapped[int] = mapped_column(Integer, default=0)
    ultimo_acceso_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    # Trazabilidad de credenciales (la clave nunca se guarda en claro: solo su hash Argon2id)
    clave_actualizada_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    clave_actualizada_por_id: Mapped[int | None] = mapped_column(
        ForeignKey("usuarios.id", ondelete="SET NULL", name="fk_usuarios_clave_actualizada_por")
    )

    conductor: Mapped[Conductor | None] = relationship(back_populates="usuario", uselist=False)
    clave_actualizada_por: Mapped[Usuario | None] = relationship(remote_side=[id])


class Conductor(TimestampMixin, Base):
    __tablename__ = "conductores"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    cedula: Mapped[str] = mapped_column(String(20), unique=True, index=True)
    nombre: Mapped[str] = mapped_column(String(160))
    telefono: Mapped[str | None] = mapped_column(String(40))
    placa: Mapped[str | None] = mapped_column(String(20))
    activo: Mapped[bool] = mapped_column(Boolean, default=True)
    usuario_id: Mapped[int | None] = mapped_column(
        ForeignKey("usuarios.id", ondelete="SET NULL"), unique=True
    )

    usuario: Mapped[Usuario | None] = relationship(back_populates="conductor")


class Camion(TimestampMixin, Base):
    __tablename__ = "camiones"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    placa: Mapped[str] = mapped_column(String(20), unique=True, index=True)
    color: Mapped[str | None] = mapped_column(String(40))
    serial: Mapped[str | None] = mapped_column(String(60))
    clase: Mapped[str | None] = mapped_column(String(40))
    activo: Mapped[bool] = mapped_column(Boolean, default=True)


class Vendedor(TimestampMixin, Base):
    __tablename__ = "vendedores"

    codigo: Mapped[str] = mapped_column(String(20), primary_key=True)
    nombre: Mapped[str] = mapped_column(String(160))
    territorio: Mapped[str | None] = mapped_column(String(80))
    email: Mapped[str | None] = mapped_column(String(200))
    activo: Mapped[bool] = mapped_column(Boolean, default=True)


class Importacion(Base):
    __tablename__ = "importaciones"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    archivo_nombre: Mapped[str] = mapped_column(String(255))
    archivo_sha256: Mapped[str] = mapped_column(String(64), index=True)
    hoja: Mapped[str] = mapped_column(String(120))
    estado: Mapped[str] = mapped_column(String(20), index=True)
    creado_por_id: Mapped[int | None] = mapped_column(ForeignKey("usuarios.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    confirmado_at: Mapped[datetime | None] = mapped_column(UTCDateTime())
    resumen: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    datos: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    resultado: Mapped[dict[str, Any] | None] = mapped_column(JSON)
    revision_ia: Mapped[str | None] = mapped_column(Text)


class Remesa(TimestampMixin, Base):
    __tablename__ = "remesas"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    numero: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    numero_generado: Mapped[bool] = mapped_column(Boolean, default=False)
    empresa: Mapped[str | None] = mapped_column(String(120))
    destino: Mapped[str | None] = mapped_column(String(160))
    conductor_id: Mapped[int | None] = mapped_column(
        ForeignKey("conductores.id", ondelete="SET NULL"), index=True
    )
    chofer_cedula: Mapped[str | None] = mapped_column(String(20))
    chofer_nombre: Mapped[str | None] = mapped_column(String(160))
    chofer_telefono: Mapped[str | None] = mapped_column(String(40))
    placa: Mapped[str | None] = mapped_column(String(20))
    importacion_id: Mapped[int | None] = mapped_column(ForeignKey("importaciones.id", ondelete="SET NULL"))
    fila_origen: Mapped[int | None] = mapped_column(Integer)

    conductor: Mapped[Conductor | None] = relationship()
    facturas: Mapped[list[Factura]] = relationship(
        back_populates="remesa", cascade="all, delete-orphan", order_by="Factura.id"
    )


class Factura(TimestampMixin, Base):
    __tablename__ = "facturas"
    __table_args__ = (
        UniqueConstraint("remesa_id", "numero", name="uq_factura_remesa_numero"),
        Index("ix_facturas_conductor_estatus", "conductor_id", "estatus"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    remesa_id: Mapped[int] = mapped_column(ForeignKey("remesas.id", ondelete="CASCADE"), index=True)
    conductor_id: Mapped[int | None] = mapped_column(ForeignKey("conductores.id", ondelete="SET NULL"))
    empresa: Mapped[str | None] = mapped_column(String(120))
    numero: Mapped[str] = mapped_column(String(40), index=True)
    pedido: Mapped[str | None] = mapped_column(String(40), index=True)
    cod_vendedor: Mapped[str | None] = mapped_column(String(20), index=True)
    cliente: Mapped[str | None] = mapped_column(String(255))
    fecha_fac: Mapped[date | None] = mapped_column(Date)
    fecha_alm: Mapped[date | None] = mapped_column(Date)
    fecha_rec: Mapped[date | None] = mapped_column(Date)
    bultos: Mapped[int | None] = mapped_column(Integer)
    total_fact: Mapped[Decimal | None] = mapped_column(MONEY)
    porcentaje: Mapped[Decimal | None] = mapped_column(Numeric(8, 4))
    total_neto: Mapped[Decimal | None] = mapped_column(MONEY)
    flete_pct: Mapped[Decimal | None] = mapped_column(Numeric(8, 4))
    total_flete: Mapped[Decimal | None] = mapped_column(MONEY)
    comentario: Mapped[str | None] = mapped_column(Text)
    fila_origen: Mapped[int | None] = mapped_column(Integer)

    estatus: Mapped[str] = mapped_column(String(20), index=True)
    estatus_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    tracking: Mapped[str | None] = mapped_column(String(20), unique=True, index=True)
    version: Mapped[int] = mapped_column(Integer, default=0)

    remesa: Mapped[Remesa] = relationship(back_populates="facturas")
    eventos: Mapped[list[EventoEstatus]] = relationship(
        back_populates="factura", cascade="all, delete-orphan", order_by="EventoEstatus.ocurrido_at"
    )


class Foto(Base):
    __tablename__ = "fotos"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    factura_id: Mapped[int] = mapped_column(ForeignKey("facturas.id", ondelete="CASCADE"), index=True)
    ruta: Mapped[str] = mapped_column(String(500))
    content_type: Mapped[str] = mapped_column(String(60))
    bytes: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64))
    subido_por_id: Mapped[int | None] = mapped_column(ForeignKey("usuarios.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    # Contenido de la imagen cuando STORAGE_BACKEND=db (Vercel no tiene disco persistente).
    datos: Mapped[Optional[builtins.bytes]] = mapped_column(LargeBinary, nullable=True, deferred=True)  # noqa: UP045


class EventoEstatus(Base):
    __tablename__ = "eventos_estatus"

    # UUID generado por el cliente: clave de idempotencia para la cola offline.
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    factura_id: Mapped[int] = mapped_column(ForeignKey("facturas.id", ondelete="CASCADE"), index=True)
    estatus: Mapped[str] = mapped_column(String(20))
    estatus_anterior: Mapped[str | None] = mapped_column(String(20))
    ocurrido_at: Mapped[datetime] = mapped_column(UTCDateTime(), index=True)
    recibido_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow)
    usuario_id: Mapped[int | None] = mapped_column(ForeignKey("usuarios.id", ondelete="SET NULL"))
    origen: Mapped[str] = mapped_column(String(20))
    motivo: Mapped[str | None] = mapped_column(Text)
    foto_id: Mapped[str | None] = mapped_column(ForeignKey("fotos.id", ondelete="SET NULL"))
    # False cuando llegó tarde (offline) y ya existía un cambio posterior: queda en el historial.
    aplicado: Mapped[bool] = mapped_column(Boolean, default=True)

    factura: Mapped[Factura] = relationship(back_populates="eventos")
    usuario: Mapped[Usuario | None] = relationship()
    foto: Mapped[Foto | None] = relationship()


class ConsultaPublica(Base):
    """Registro anónimo de consultas públicas (métrica 'vendedores autónomos')."""

    __tablename__ = "consultas_publicas"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    termino: Mapped[str] = mapped_column(String(60))
    encontrado: Mapped[bool] = mapped_column(Boolean)
    ip_hash: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, index=True)


class Auditoria(Base):
    """Bitácora de acciones sensibles (altas, cambios de rol, claves). Nunca guarda claves ni hashes."""

    __tablename__ = "auditoria"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime(), default=utcnow, index=True)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("usuarios.id", ondelete="SET NULL"))
    actor_rol: Mapped[str | None] = mapped_column(String(20))
    accion: Mapped[str] = mapped_column(String(40), index=True)
    objetivo_usuario_id: Mapped[int | None] = mapped_column(
        ForeignKey("usuarios.id", ondelete="SET NULL"), index=True
    )
    detalle: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
