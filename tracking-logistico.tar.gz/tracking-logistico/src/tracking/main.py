"""Fábrica de la aplicación FastAPI: API + PWA estática."""

from __future__ import annotations

import json
import logging
import time
import uuid
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text

from tracking import __version__
from tracking.api import admin, auth, conductor, importaciones, publico, remesas, reportes
from tracking.config import Settings, get_settings
from tracking.db import Database
from tracking.logging_config import configure_logging, request_id_var
from tracking.ratelimit import SlidingWindowLimiter
from tracking.services.ai import ClaudeClient
from tracking.services.photos import PhotoStorage
from tracking.services.users import asegurar_supervisor_inicial

log = logging.getLogger("tracking")
WEB_DIR = Path(__file__).parent / "web"

CSP = (
    "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
    "script-src 'self'; connect-src 'self'; worker-src 'self'; manifest-src 'self'; "
    "frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
)


def create_app(settings: Settings | None = None, database: Database | None = None) -> FastAPI:
    settings = settings or get_settings()
    configure_logging(settings.log_level, settings.log_json)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        db: Database = app.state.db
        db.wait_until_ready()
        if settings.db_auto_migrate:
            from tracking.migrate import upgrade_head

            upgrade_head(db.engine)
        with db.session() as s:
            asegurar_supervisor_inicial(s, settings.bootstrap_admin_user, settings.bootstrap_admin_password)
        log.info("app_iniciada", extra={"env": settings.app_env, "version": __version__,
                                        "ia": settings.ai_available, "correo": settings.email_enabled})
        yield
        app.state.ai.close()
        db.engine.dispose()

    app = FastAPI(
        title=settings.app_name,
        version=__version__,
        lifespan=lifespan,
        docs_url="/api/docs",
        openapi_url="/api/openapi.json",
        redoc_url=None,
    )
    app.state.settings = settings
    # Las rutas reciben exactamente esta configuración (clave JWT, límites, etc.)
    app.dependency_overrides[get_settings] = lambda: settings
    app.state.db = database or Database(settings)
    # En Vercel el disco es de solo lectura: las fotos van a la base (STORAGE_BACKEND=db)
    app.state.photos = PhotoStorage(settings.storage_dir) if settings.storage_backend == "disk" else None
    app.state.ai = ClaudeClient(settings)
    app.state.login_limiter = SlidingWindowLimiter(settings.login_max_attempts, settings.login_window_seconds)
    app.state.public_limiter = SlidingWindowLimiter(settings.public_rate_limit_per_minute, 60)

    app.add_middleware(GZipMiddleware, minimum_size=1024)
    if settings.cors_origin_list:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.cors_origin_list,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    @app.middleware("http")
    async def request_context(
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        rid = request.headers.get("x-request-id") or uuid.uuid4().hex[:16]
        token = request_id_var.set(rid)
        start = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            log.exception("error_no_controlado", extra={"path": request.url.path})
            response = JSONResponse({"detail": "Error interno. Código: " + rid}, status_code=500)
        finally:
            request_id_var.reset(token)
        ms = round((time.perf_counter() - start) * 1000, 1)
        response.headers["X-Request-ID"] = rid
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = CSP
        response.headers["Permissions-Policy"] = "camera=(self), geolocation=()"
        if request.url.path.startswith("/api/") and request.url.path != "/api/docs":
            log.info("http", extra={"method": request.method, "path": request.url.path,
                                    "status": response.status_code, "ms": ms, "request_id": rid})
        return response

    for r in (auth.router, importaciones.router, conductor.router, remesas.router, admin.router,
              publico.router, reportes.router):
        app.include_router(r)

    @app.get("/health", include_in_schema=False)
    def health() -> dict[str, str]:
        with app.state.db.engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return {"status": "ok", "version": __version__}

    @app.get("/api/config", tags=["publico"])
    def public_config() -> dict[str, object]:
        return {"app": settings.app_name, "version": __version__, "correo": settings.email_enabled,
                "ia": settings.ai_available, "max_foto_mb": settings.max_photo_mb}

    # ---------------- PWA estática ----------------
    def page(name: str) -> Callable[[], FileResponse]:
        def _serve() -> FileResponse:
            return FileResponse(WEB_DIR / name, headers={"Cache-Control": "no-cache"})

        return _serve

    for ruta, archivo in (("/", "index.html"), ("/conductor", "conductor.html"), ("/panel", "panel.html"),
                          ("/tracking", "tracking.html")):
        app.add_api_route(ruta, page(archivo), include_in_schema=False, methods=["GET"])

    @app.get("/.well-known/assetlinks.json", include_in_schema=False)
    def assetlinks() -> JSONResponse:
        """Digital Asset Links: permite que el APK (TWA) abra la app a pantalla completa, sin barra."""
        if settings.android_assetlinks_json:
            try:
                return JSONResponse(json.loads(settings.android_assetlinks_json))
            except ValueError:
                log.error("ANDROID_ASSETLINKS_JSON no es un JSON válido")
                return JSONResponse([], status_code=500)
        if not settings.android_package_name or not settings.android_fingerprint_list:
            return JSONResponse([], status_code=404)
        return JSONResponse([{
            "relation": ["delegate_permission/common.handle_all_urls"],
            "target": {
                "namespace": "android_app",
                "package_name": settings.android_package_name,
                "sha256_cert_fingerprints": settings.android_fingerprint_list,
            },
        }])

    @app.get("/sw.js", include_in_schema=False)
    def service_worker() -> FileResponse:
        return FileResponse(WEB_DIR / "sw.js", media_type="application/javascript",
                            headers={"Cache-Control": "no-cache", "Service-Worker-Allowed": "/"})

    @app.get("/manifest.webmanifest", include_in_schema=False)
    def manifest() -> FileResponse:
        return FileResponse(WEB_DIR / "manifest.webmanifest", media_type="application/manifest+json")

    app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")
    return app


def app_factory() -> FastAPI:
    """Punto de entrada para uvicorn: `uvicorn tracking.main:app_factory --factory`."""
    return create_app()
