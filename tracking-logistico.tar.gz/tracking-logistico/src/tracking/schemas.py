"""Esquemas Pydantic de entrada/salida de la API."""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from tracking.enums import Estatus, Rol


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# --------------------------------------------------------------------- Auth
class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=200)

    @field_validator("username")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


class UsuarioOut(ORM):
    id: int
    username: str
    nombre: str
    rol: str
    email: str | None = None
    activo: bool
    debe_cambiar_clave: bool
    conductor_id: int | None = None


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expira: datetime
    usuario: UsuarioOut


class CambioClaveIn(BaseModel):
    clave_actual: str
    clave_nueva: str = Field(min_length=6, max_length=200)


class PerfilConductorIn(BaseModel):
    nombre: str | None = Field(default=None, min_length=2, max_length=160)
    placa: str | None = Field(default=None, max_length=20)
    telefono: str | None = Field(default=None, max_length=40)


# --------------------------------------------------------------- Catálogos
class ConductorIn(BaseModel):
    cedula: str = Field(min_length=3, max_length=20)
    nombre: str = Field(min_length=2, max_length=160)
    telefono: str | None = Field(default=None, max_length=40)
    placa: str | None = Field(default=None, max_length=20)
    clave: str | None = Field(default=None, min_length=6, max_length=200)
    activo: bool = True


class ConductorUpdate(BaseModel):
    nombre: str | None = Field(default=None, min_length=2, max_length=160)
    telefono: str | None = Field(default=None, max_length=40)
    placa: str | None = Field(default=None, max_length=20)
    activo: bool | None = None


class ConductorOut(ORM):
    id: int
    cedula: str | None
    nombre: str
    telefono: str | None
    placa: str | None
    activo: bool
    usuario_id: int | None


class CamionIn(BaseModel):
    placa: str = Field(min_length=3, max_length=20)
    color: str | None = Field(default=None, max_length=40)
    serial: str | None = Field(default=None, max_length=60)
    clase: str | None = Field(default=None, max_length=40)
    activo: bool = True


class CamionUpdate(BaseModel):
    color: str | None = Field(default=None, max_length=40)
    serial: str | None = Field(default=None, max_length=60)
    clase: str | None = Field(default=None, max_length=40)
    activo: bool | None = None


class CamionOut(ORM):
    id: int
    placa: str
    color: str | None
    serial: str | None
    clase: str | None
    activo: bool


class UsuarioIn(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    nombre: str = Field(min_length=2, max_length=160)
    rol: Literal["supervisor", "transportista", "cobranzas"]
    email: str | None = Field(default=None, max_length=200)
    clave: str | None = Field(default=None, min_length=6, max_length=200)


class UsuarioUpdate(BaseModel):
    nombre: str | None = Field(default=None, min_length=2, max_length=160)
    rol: Literal["supervisor", "transportista", "cobranzas"] | None = None
    email: str | None = Field(default=None, max_length=200)
    activo: bool | None = None


class VendedorIn(BaseModel):
    codigo: str = Field(min_length=2, max_length=20)
    nombre: str = Field(min_length=2, max_length=160)
    territorio: str | None = Field(default=None, max_length=80)
    email: str | None = Field(default=None, max_length=200)
    activo: bool = True


class VendedorUpdate(BaseModel):
    nombre: str | None = Field(default=None, min_length=2, max_length=160)
    territorio: str | None = Field(default=None, max_length=80)
    email: str | None = Field(default=None, max_length=200)
    activo: bool | None = None


class VendedorOut(ORM):
    codigo: str
    nombre: str
    territorio: str | None
    email: str | None
    activo: bool


class CredencialTemporal(BaseModel):
    usuario: str
    nombre: str
    clave_temporal: str


# ------------------------------------------------------------ Importación
class FilasExcelIn(BaseModel):
    archivo: str = Field(default="remesa.xlsx", max_length=255)
    hoja: str = Field(default="", max_length=120)
    hojas: list[str] = Field(default_factory=list, max_length=200)
    sha256: str | None = Field(default=None, max_length=64)
    filas: list[list[Any]] = Field(max_length=300_000)


class ConfirmarImportacionIn(BaseModel):
    remesas: list[str] | None = Field(
        default=None, description="Números de remesa a importar. Vacío = las sugeridas (nuevas)."
    )
    fecha_desde: date | None = Field(default=None, description="Solo remesas con fecha >= esta fecha")
    registrar_choferes: bool = Field(
        default=False, description="Registrar automáticamente choferes que no existen en el sistema"
    )


class ImportacionOut(ORM):
    id: int
    archivo_nombre: str
    hoja: str
    estado: str
    created_at: datetime
    confirmado_at: datetime | None
    resumen: dict[str, Any]
    resultado: dict[str, Any] | None = None
    revision_ia: str | None = None


class ResultadoConfirmacionOut(BaseModel):
    importacion_id: int
    remesas_creadas: int
    remesas_actualizadas: int
    facturas_creadas: int
    facturas_omitidas: int
    choferes_registrados: list[CredencialTemporal]
    remesas_excluidas: list[str]


# ----------------------------------------------------------------- Estatus
class EventoIn(BaseModel):
    id: str = Field(min_length=8, max_length=36, description="UUID generado en el dispositivo")
    factura_id: int
    estatus: Estatus
    ocurrido_at: datetime | None = None
    motivo: str | None = Field(default=None, max_length=1000)
    foto_id: str | None = Field(default=None, max_length=36)
    offline: bool = False


class LoteEventosIn(BaseModel):
    eventos: list[EventoIn] = Field(min_length=1, max_length=500)


class EventoResultado(BaseModel):
    id: str
    ok: bool
    aplicado: bool = False
    duplicado: bool = False
    factura_id: int
    estatus_actual: str | None = None
    estatus_at: datetime | None = None
    tracking: str | None = None
    error: str | None = None
    codigo_error: (
        Literal["conflicto", "foto_pendiente", "no_encontrada", "sin_permiso", "invalido"] | None
    ) = None


class LoteEventosOut(BaseModel):
    resultados: list[EventoResultado]
    servidor_at: datetime


class CambioEstatusAdminIn(BaseModel):
    estatus: Estatus
    motivo: str | None = Field(default=None, max_length=1000)


class ReasignarRemesaIn(BaseModel):
    conductor_id: int


# ---------------------------------------------------------------- Lectura
class EventoOut(ORM):
    id: str
    estatus: str
    estatus_anterior: str | None
    ocurrido_at: datetime
    recibido_at: datetime
    origen: str
    motivo: str | None
    foto_id: str | None
    aplicado: bool
    usuario_nombre: str | None = None


class FacturaConductorOut(ORM):
    id: int
    numero: str
    pedido: str | None
    cliente: str | None
    empresa: str | None
    bultos: int | None
    comentario: str | None
    estatus: str
    estatus_at: datetime
    tracking: str | None
    remesa_id: int
    remesa_numero: str
    destino: str | None
    tiene_foto: bool = False


class FacturaOut(ORM):
    id: int
    numero: str
    pedido: str | None
    cod_vendedor: str | None
    cliente: str | None
    empresa: str | None
    fecha_fac: date | None
    fecha_alm: date | None
    fecha_rec: date | None
    bultos: int | None
    total_fact: Decimal | None
    porcentaje: Decimal | None
    total_neto: Decimal | None
    flete_pct: Decimal | None
    total_flete: Decimal | None
    comentario: str | None
    estatus: str
    estatus_at: datetime
    tracking: str | None
    remesa_id: int
    remesa_numero: str | None = None
    conductor_nombre: str | None = None


class FacturaDetalleOut(FacturaOut):
    eventos: list[EventoOut] = Field(default_factory=list)


class RemesaOut(ORM):
    id: int
    numero: str
    numero_generado: bool
    empresa: str | None
    destino: str | None
    conductor_id: int | None
    chofer_nombre: str | None
    chofer_cedula: str | None = None
    chofer_telefono: str | None = None
    placa: str | None
    created_at: datetime
    total_facturas: int = 0
    por_estatus: dict[str, int] = Field(default_factory=dict)
    progreso: float = 0.0


class RemesaDetalleOut(RemesaOut):
    facturas: list[FacturaOut] = Field(default_factory=list)


class Pagina(BaseModel):
    total: int
    items: list[Any]


# ---------------------------------------------------------- Consulta pública
class HitoPublico(BaseModel):
    estatus: str
    fecha: datetime


class TrackingPublicoOut(BaseModel):
    numero: str
    pedido: str | None
    tracking: str | None
    empresa: str | None
    cliente: str | None
    destino: str | None
    estatus: str
    estatus_at: datetime
    historial: list[HitoPublico]


class ConsultaPublicaOut(BaseModel):
    encontrado: bool
    mensaje: str | None = None
    resultados: list[TrackingPublicoOut] = Field(default_factory=list)


# ----------------------------------------------------------- Notificaciones
class NotificarVendedoresIn(BaseModel):
    modo: Literal["en_curso", "final"]
    desde: date | None = None
    hasta: date | None = None
    remesa_ids: list[int] | None = None
    simular: bool = Field(default=False, description="Arma los correos pero no los envía")


class NotificarCobranzasIn(BaseModel):
    desde: date | None = None
    hasta: date | None = None
    remesa_ids: list[int] | None = None
    solo_finales: bool = False
    simular: bool = False


class RolOut(BaseModel):
    valor: Rol
