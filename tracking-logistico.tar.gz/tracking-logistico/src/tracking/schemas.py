"""Esquemas Pydantic de entrada/salida de la API."""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator, model_validator

from tracking.enums import Estatus, Rol


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# --------------------------------------------------------------------- Auth
class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: SecretStr = Field(min_length=1, max_length=200)

    @field_validator("username")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


class UsuarioOut(ORM):
    id: int
    username: str
    nombre: str
    rol: str
    email: str | None = None
    activo: bool
    debe_cambiar_clave: bool
    conductor_id: int | None = None


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expira: datetime
    usuario: UsuarioOut


class CambioClaveIn(BaseModel):
    clave_actual: SecretStr = Field(max_length=200)
    clave_nueva: SecretStr = Field(min_length=6, max_length=200)


class PerfilConductorIn(BaseModel):
    nombre: str | None = Field(default=None, min_length=2, max_length=160)
    placa: str | None = Field(default=None, max_length=20)
    telefono: str | None = Field(default=None, max_length=40)


# --------------------------------------------------------------- Catálogos
class ConductorIn(BaseModel):
    cedula: str = Field(min_length=3, max_length=20)
    nombre: str = Field(min_length=2, max_length=160)
    telefono: str | None = Field(default=None, max_length=40)
    placa: str | None = Field(default=None, max_length=20)
    clave: SecretStr | None = Field(default=None, min_length=6, max_length=200)
    activo: bool = True


class ConductorUpdate(BaseModel):
    nombre: str | None = Field(default=None, min_length=2, max_length=160)
    telefono: str | None = Field(default=None, max_length=40)
    placa: str | None = Field(default=None, max_length=20)
    activo: bool | None = None


class ConductorOut(ORM):
    id: int
    cedula: str | None
    nombre: str
    telefono: str | None
    placa: str | None
    activo: bool
    usuario_id: int | None


class CamionIn(BaseModel):
    placa: str = Field(min_length=3, max_length=20)
    color: str | None = Field(default=None, max_length=40)
    serial: str | None = Field(default=None, max_length=60)
    clase: str | None = Field(default=None, max_length=40)
    activo: bool = True


class CamionUpdate(BaseModel):
    color: str | None = Field(default=None, max_length=40)
    serial: str | None = Field(default=None, max_length=60)
    clase: str | None = Field(default=None, max_length=40)
    activo: bool | None = None


class CamionOut(ORM):
    id: int
    placa: str
    color: str | None
    serial: str | None
    clase: str | None
    activo: bool


class UsuarioIn(BaseModel):
    """Alta de usuario. Para rol CONDUCTOR el usuario de acceso es la cédula."""

    username: str | None = Field(default=None, min_length=3, max_length=64)
    nombre: str = Field(min_length=2, max_length=160)
    rol: Rol
    email: str | None = Field(default=None, max_length=200)
    clave: SecretStr | None = Field(default=None, min_length=6, max_length=200)
    # Solo para rol CONDUCTOR
    cedula: str | None = Field(default=None, min_length=3, max_length=20)
    telefono: str | None = Field(default=None, max_length=40)
    placa: str | None = Field(default=None, max_length=20)

    @model_validator(mode="after")
    def _campos_por_rol(self) -> UsuarioIn:
        if self.rol == Rol.CONDUCTOR:
            if not self.cedula:
                raise ValueError("Para un CONDUCTOR indique la cédula (será su usuario de acceso)")
        elif not self.username:
            raise ValueError("Indique el nombre de usuario")
        return self


class UsuarioUpdate(BaseModel):
    nombre: str | None = Field(default=None, min_length=2, max_length=160)
    rol: Literal["supervisor", "transportista", "cobranzas"] | None = None
    email: str | None = Field(default=None, max_length=200)
    activo: bool | None = None


class EstablecerClaveIn(BaseModel):
    """Clave asignada por un administrador. Sin `clave_nueva` se genera una temporal aleatoria."""

    clave_nueva: SecretStr | None = Field(default=None, min_length=6, max_length=200)
    debe_cambiar_clave: bool = Field(default=True, description="Obligar al usuario a cambiarla en su próximo ingreso")


class ResultadoClaveOut(BaseModel):
    usuario_id: int
    usuario: str
    nombre: str
    debe_cambiar_clave: bool
    # Solo presente cuando el sistema generó la clave: se muestra UNA vez y no se guarda en claro
    clave_temporal: str | None = None


class EstadoCredencialOut(BaseModel):
    """Lo que un SUPERVISOR puede consultar de una credencial. Nunca incluye la clave ni su hash."""

    usuario_id: int
    usuario: str
    nombre: str
    rol: str
    activo: bool
    tiene_clave: bool
    algoritmo: str
    debe_cambiar_clave: bool
    clave_actualizada_at: datetime | None
    clave_actualizada_por: str | None
    ultimo_acceso_at: datetime | None
    nota: str = (
        "Las claves se guardan cifradas con Argon2id (irreversible): no se pueden mostrar. "
        "Para entregar una clave al usuario, restablézcala."
    )


class AuditoriaOut(ORM):
    id: int
    created_at: datetime
    actor_id: int | None
    actor_rol: str | None
    accion: str
    objetivo_usuario_id: int | None
    detalle: dict[str, Any]


class PermisosOut(BaseModel):
    rol: str
    permisos: list[str]


class VendedorIn(BaseModel):
    codigo: str = Field(min_length=2, max_length=20)
    nombre: str = Field(min_length=2, max_length=160)
    territorio: str | None = Field(default=None, max_length=80)
    email: str | None = Field(default=None, max_length=200)
    activo: bool = True


class VendedorUpdate(BaseModel):
    nombre: str | None = Field(default=None, min_length=2, max_length=160)
    territorio: str | None = Field(default=None, max_length=80)
    email: str | None = Field(default=None, max_length=200)
    activo: bool | None = None


class VendedorOut(ORM):
    codigo: str
    nombre: str
    territorio: str | None
    email: str | None
    activo: bool


class CredencialTemporal(BaseModel):
    usuario: str
    nombre: str
    clave_temporal: str


# ------------------------------------------------------------ Importación
class FilasExcelIn(BaseModel):
    archivo: str = Field(default="remesa.xlsx", max_length=255)
    hoja: str = Field(default="", max_length=120)
    hojas: list[str] = Field(default_factory=list, max_length=200)
    sha256: str | None = Field(default=None, max_length=64)
    filas: list[list[Any]] = Field(max_length=300_000)


class ConfirmarImportacionIn(BaseModel):
    remesas: list[str] | None = Field(
        default=None, description="Números de remesa a importar. Vacío = las sugeridas (nuevas)."
    )
    fecha_desde: date | None = Field(default=None, description="Solo remesas con fecha >= esta fecha")
    registrar_choferes: bool = Field(
        default=False, description="Registrar automáticamente choferes que no existen en el sistema"
    )


class ImportacionOut(ORM):
    id: int
    archivo_nombre: str
    hoja: str
    estado: str
    created_at: datetime
    confirmado_at: datetime | None
    resumen: dict[str, Any]
    resultado: dict[str, Any] | None = None
    revision_ia: str | None = None


class ResultadoConfirmacionOut(BaseModel):
    importacion_id: int
    remesas_creadas: int
    remesas_actualizadas: int
    facturas_creadas: int
    facturas_omitidas: int
    choferes_registrados: list[CredencialTemporal]
    remesas_excluidas: list[str]


# ----------------------------------------------------------------- Estatus
class EventoIn(BaseModel):
    id: str = Field(min_length=8, max_length=36, description="UUID generado en el dispositivo")
    factura_id: int
    estatus: Estatus
    ocurrido_at: datetime | None = None
    motivo: str | None = Field(default=None, max_length=1000)
    foto_id: str | None = Field(default=None, max_length=36)
    offline: bool = False


class EventoOperativoIn(BaseModel):
    """Cuerpo de POST /api/conductor/facturas/{id}/{tipo}: el estatus lo determina el tipo de evento."""

    id: str = Field(min_length=8, max_length=36, description="UUID generado en el dispositivo")
    ocurrido_at: datetime | None = None
    motivo: str | None = Field(default=None, max_length=1000)
    foto_id: str | None = Field(default=None, max_length=36)
    offline: bool = False


class LoteEventosIn(BaseModel):
    eventos: list[EventoIn] = Field(min_length=1, max_length=500)


class EventoResultado(BaseModel):
    id: str
    ok: bool
    aplicado: bool = False
    duplicado: bool = False
    factura_id: int
    estatus_actual: str | None = None
    estatus_at: datetime | None = None
    tracking: str | None = None
    error: str | None = None
    codigo_error: Literal["conflicto", "foto_pendiente", "no_encontrada", "sin_permiso", "invalido"] | None = None


class LoteEventosOut(BaseModel):
    resultados: list[EventoResultado]
    servidor_at: datetime


class CambioEstatusAdminIn(BaseModel):
    estatus: Estatus
    motivo: str | None = Field(default=None, max_length=1000)


class ReasignarRemesaIn(BaseModel):
    conductor_id: int


# ---------------------------------------------------------------- Lectura
class EventoOut(ORM):
    id: str
    estatus: str
    estatus_anterior: str | None
    ocurrido_at: datetime
    recibido_at: datetime
    origen: str
    motivo: str | None
    foto_id: str | None
    aplicado: bool
    usuario_nombre: str | None = None


class FacturaConductorOut(ORM):
    id: int
    numero: str
    pedido: str | None
    cliente: str | None
    empresa: str | None
    bultos: int | None
    comentario: str | None
    estatus: str
    estatus_at: datetime
    tracking: str | None
    remesa_id: int
    remesa_numero: str
    destino: str | None
    tiene_foto: bool = False


class EventoConductorOut(ORM):
    id: str
    estatus: str
    ocurrido_at: datetime
    aplicado: bool
    motivo: str | None
    foto_id: str | None


class FacturaConductorDetalleOut(FacturaConductorOut):
    eventos: list[EventoConductorOut] = Field(default_factory=list)


class RemesaConductorOut(BaseModel):
    """Vista de remesa para el conductor: sin montos ni datos de otros conductores."""

    id: int
    numero: str
    empresa: str | None
    destino: str | None
    placa: str | None
    created_at: datetime
    total_facturas: int
    por_estatus: dict[str, int]
    progreso: float


class RemesaConductorDetalleOut(RemesaConductorOut):
    facturas: list[FacturaConductorOut] = Field(default_factory=list)


class FacturaOut(ORM):
    id: int
    numero: str
    pedido: str | None
    cod_vendedor: str | None
    cliente: str | None
    empresa: str | None
    fecha_fac: date | None
    fecha_alm: date | None
    fecha_rec: date | None
    bultos: int | None
    total_fact: Decimal | None
    porcentaje: Decimal | None
    total_neto: Decimal | None
    flete_pct: Decimal | None
    total_flete: Decimal | None
    comentario: str | None
    estatus: str
    estatus_at: datetime
    tracking: str | None
    remesa_id: int
    remesa_numero: str | None = None
    conductor_nombre: str | None = None


class FacturaDetalleOut(FacturaOut):
    eventos: list[EventoOut] = Field(default_factory=list)


class RemesaOut(ORM):
    id: int
    numero: str
    numero_generado: bool
    empresa: str | None
    destino: str | None
    conductor_id: int | None
    chofer_nombre: str | None
    chofer_cedula: str | None = None
    chofer_telefono: str | None = None
    placa: str | None
    created_at: datetime
    total_facturas: int = 0
    por_estatus: dict[str, int] = Field(default_factory=dict)
    progreso: float = 0.0


class RemesaDetalleOut(RemesaOut):
    facturas: list[FacturaOut] = Field(default_factory=list)


class Pagina(BaseModel):
    total: int
    items: list[Any]


# ---------------------------------------------------------- Consulta pública
class HitoPublico(BaseModel):
    estatus: str
    fecha: datetime


class TrackingPublicoOut(BaseModel):
    numero: str
    pedido: str | None
    tracking: str | None
    empresa: str | None
    cliente: str | None
    destino: str | None
    estatus: str
    estatus_at: datetime
    historial: list[HitoPublico]


class ConsultaPublicaOut(BaseModel):
    encontrado: bool
    mensaje: str | None = None
    resultados: list[TrackingPublicoOut] = Field(default_factory=list)


# ----------------------------------------------------------- Notificaciones
class NotificarVendedoresIn(BaseModel):
    modo: Literal["en_curso", "final"]
    desde: date | None = None
    hasta: date | None = None
    remesa_ids: list[int] | None = None
    simular: bool = Field(default=False, description="Arma los correos pero no los envía")


class NotificarCobranzasIn(BaseModel):
    desde: date | None = None
    hasta: date | None = None
    remesa_ids: list[int] | None = None
    solo_finales: bool = False
    simular: bool = False


class RolOut(BaseModel):
    valor: Rol
