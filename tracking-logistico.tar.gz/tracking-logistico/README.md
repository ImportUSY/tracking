# Tracking Logístico

Seguimiento de cada factura desde que llega a Transporte hasta que se **entrega** o se **devuelve**.
Transporte carga la hoja **REMESA**, el conductor cambia estatus desde el teléfono (incluso **sin señal**),
los vendedores consultan sin clave y Cobranzas descarga su Excel con el formato de siempre (Libro2).

| Quién | Dónde entra | Qué hace |
|---|---|---|
| Supervisor | `/panel` | Todo, incluidos usuarios y borrado de remesas |
| Transportista | `/panel` | Carga REMESA, conductores, camiones, vendedores, correcciones, Excel/correos |
| Cobranzas | `/panel` | Solo lectura + Excel de entregas (no ve cédulas ni teléfonos) |
| Conductor | `/conductor` (PWA instalable) | Ve solo sus facturas; Cargado → En Tránsito → Entregada / Devolución con foto |
| Vendedor | `/tracking` (sin clave) | Consulta por factura, pedido o tracking (sin montos ni datos personales) |

---

## 1. Puesta en marcha rápida

> **Publicar en internet con Vercel**: vea **[DESPLIEGUE_VERCEL.md](DESPLIEGUE_VERCEL.md)**
> (un comando en Windows: `powershell -ExecutionPolicy Bypass -File scripts\deploy_vercel.ps1`).
> **APK para Android**: vea **[APK_ANDROID.md](APK_ANDROID.md)**.

### Windows (desarrollo / prueba local)

```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
.\.venv\Scripts\tracking.exe crear-supervisor          # pide la clave
powershell -File scripts\run_dev.ps1                     # http://localhost:8000
```

### Linux / macOS

```bash
bash scripts/setup.sh
.venv/bin/tracking crear-supervisor
bash scripts/run_dev.sh
```

### Producción con Docker (PostgreSQL + HTTPS + respaldos)

```bash
cp .env.example .env      # complete SECRET_KEY, POSTGRES_PASSWORD, DOMAIN, BOOTSTRAP_ADMIN_PASSWORD
docker compose up -d --build
docker compose exec app tracking crear-supervisor   # si no definió BOOTSTRAP_ADMIN_PASSWORD
```

> **HTTPS es obligatorio en producción**: los navegadores solo permiten el modo sin señal (service
> worker) y la instalación de la app en sitios `https://`. El `docker-compose.yml` incluye Caddy, que
> obtiene el certificado automáticamente para `DOMAIN`.

Respaldos: el servicio `backup` guarda cada 24 h un `pg_dump` en `./backups` (retención
`BACKUP_RETENTION_DAYS`) y copia incremental de las fotos. Restaurar:
`pg_restore -h <host> -U tracking -d tracking --clean backups/tracking_AAAAMMDD_HHMM.dump`.

## 2. Primer uso

1. Entrar a `/panel` como supervisor.
2. **Conductores → Cargar desde Excel**: suba `REMESA.xlsx` (hoja `PLACAS`). Crea conductores y camiones
   y muestra **una sola vez** las claves temporales (imprímalas). El conductor entra con su **cédula**
   y se le pide crear su clave personal.
3. **Vendedores → Cargar desde Excel**: suba `Listado Codigo Vendedores.xlsx`; agregue correos si
   usará los avisos.
4. **Cargar REMESA**: suba el libro, revise el resumen (avisos, choferes sin registrar, remesas
   nuevas), elija qué remesas cargar (por defecto las nuevas; use *Solo desde* para no cargar el
   histórico del año) y confirme. Las facturas quedan en **Recibida**, asignadas a su conductor.
5. El conductor abre `https://<dominio>/conductor` en el teléfono → menú del navegador →
   *Agregar a pantalla de inicio*.

Lo mismo por línea de comandos:

```bash
tracking cargar-placas REMESA.xlsx
tracking cargar-vendedores "Listado Codigo Vendedores.xlsx"
tracking importar-remesa REMESA.xlsx                       # solo resumen
tracking importar-remesa REMESA.xlsx --confirmar --desde 2026-09-20 --registrar-choferes
```

## 3. Arquitectura

```mermaid
flowchart LR
  subgraph Teléfono del conductor
    PWA[PWA /conductor] --> IDB[(IndexedDB: caché, cola de cambios, fotos)]
    SW[Service worker] -.app sin señal.-> PWA
  end
  Panel[/panel/] --> API
  Pub[/tracking público/] --> API
  IDB -- sincroniza con reintentos --> API[FastAPI]
  API --> Parser[Parser REMESA determinista]
  API --> Estados[Máquina de estados + eventos idempotentes]
  API --> XLS[Excel Cobranzas formato Libro2]
  API -.opcional.-> IA[Claude: revisión del resumen / columnas renombradas]
  API -.opcional.-> SMTP[Correo]
  API --> DB[(PostgreSQL / SQLite)]
  API --> FS[(Fotos en disco)]
```

| Módulo | Responsabilidad |
|---|---|
| `services/remesa_parser.py` | Lee bloques `Chofer/Placa/Destino + tabla` por *streaming* (openpyxl read-only); tolera columnas movidas, empezar en A o B, números de remesa en distintas columnas, `#N/A`, facturas numéricas. Nunca inventa datos. |
| `services/importer.py` | Vista previa (no escribe) → confirmación idempotente (únicos por número de remesa y factura). Re-evalúa contra la base al confirmar. |
| `services/status.py` | Reglas de estatus, idempotencia por UUID del dispositivo, eventos tardíos del modo sin señal. |
| `web/outbox.js` | "Libreta interna": cola en IndexedDB, fotos guardadas hasta confirmar la subida, *backoff* exponencial. |
| `services/cobranzas_excel.py` | Excel idéntico a Libro2 (columnas B–N) + Cod. Vendedor, Estatus y Fecha del estatus. |
| `services/ai.py` | Opcional (`AI_REVIEW_ENABLED`). Reintentos con *backoff*; si falla, todo sigue funcionando. |

### Decisiones sobre los TBD del PRD

- **Lectura del Excel**: parser determinista como fuente de verdad (gratis, repetible, 2.000 facturas en
  segundos). La IA solo *comenta* el resumen y sugiere a qué campo corresponde una columna renombrada;
  la sugerencia se valida contra una lista cerrada y se muestra antes de confirmar.
- **Concurrencia**: todo cambio queda en el historial. Un cambio que **avanza** la factura siempre se
  aplica (aunque llegue tarde desde el modo sin señal). Entre Entregada y Devolución **gana el cambio
  más reciente** (hora en que ocurrió). Retroceder solo lo hace Supervisor/Transportista, con motivo.
- **Tracking**: nace al salir de Recibida, formato `TR-XXXXXXXX` (sin I/L/O/U para dictarlo fácil).
- **Factura repetida**: si ya está en el sistema se omite; si su último estatus es Devolución se carga
  como reenvío. Remesas sin número reciben un código estable `SN-…` (recargar no duplica).
- **Datos personales**: cédula y teléfono solo para Supervisor, Transportista y el propio conductor.
  La consulta pública no muestra montos, cédulas, teléfonos ni fotos y tiene límite por IP.
- **Métrica estrella** (`/api/reportes/metricas` y pestaña Inicio): % de cambios registrados el mismo
  día en que ocurrieron, cambios sin señal sincronizados y consultas públicas.

### Hallazgos en la REMESA real (para corregir en origen)

24 remesas sin número, la remesa `2025-00783` usada por dos choferes distintos, `2025-00794` con todas
sus facturas repetidas de otra remesa, 18 filas de factura repetidas y 3 filas sin número de factura.
El sistema las señala en el resumen antes de guardar.

## 4. API

Documentación interactiva en `/api/docs`. Principales rutas:

| Ruta | Uso |
|---|---|
| `POST /api/auth/login` | Usuario o cédula + clave → JWT |
| `POST /api/importaciones` → `POST /api/importaciones/{id}/confirmar` | Carga REMESA en dos pasos |
| `GET /api/conductor/facturas`, `POST /api/conductor/eventos` | App del conductor (lotes idempotentes) |
| `PUT /api/fotos/{uuid}` | Foto de entrega/devolución (idempotente) |
| `GET /api/publico/tracking?q=` | Consulta pública |
| `GET /api/reportes/cobranzas.xlsx` | Excel para Cobranzas |
| `POST /api/reportes/notificar/vendedores` · `/cobranzas` | Correos (`simular: true` para vista previa) |

## 5. Pruebas y calidad

```bash
pytest                       # 19 pruebas: parser, flujo completo, permisos, sin señal, Excel, IA simulada
TEST_DATABASE_URL=postgresql://usuario@localhost:5432/tracking_test pytest   # mismas pruebas en PostgreSQL
ruff check src tests && mypy # estilo y tipado estricto
```

## 6. Pendiente / siguientes pasos

- **APK**: la PWA ya es instalable; para publicar en Play Store se envuelve con Trusted Web Activity
  (Bubblewrap) o Capacitor sin reescribir la app.
- Activar correos: `EMAIL_ENABLED=true` + datos SMTP (proveedor por definir).
- Al publicar una versión nueva de la app web, subir `VERSION` en `src/tracking/web/sw.js` para que
  los teléfonos descarguen los archivos nuevos.
- Con varias réplicas del servidor, mover los límites de intentos/consultas a Redis o al proxy.
- Fuera de alcance de esta versión (PRD): mapa en vivo, rutas óptimas, OCR de la foto.
